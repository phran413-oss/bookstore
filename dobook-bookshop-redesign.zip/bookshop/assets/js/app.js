(function () {
  var body = document.body;
  var base = body.dataset.base || '';
  var logged = body.dataset.logged === '1';

  // Bookmark / wishlist
  function toggleWish(btn) {
    btn.disabled = true;
    fetch(base + '/wishlist.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'action=toggle&book_id=' + encodeURIComponent(btn.dataset.wish)
    })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        btn.classList.toggle('active', d.wished);
        btn.setAttribute('aria-pressed', d.wished ? 'true' : 'false');
        var label = btn.querySelector('.wish-label');
        if (label) label.textContent = d.wished ? 'Tersimpan di wishlist' : 'Simpan ke wishlist';
        if (!d.wished && document.querySelector('[data-wishlist-page]')) location.reload();
      })
      .catch(function () {})
      .then(function () { btn.disabled = false; });
  }

  document.addEventListener('click', function (e) {
    var w = e.target.closest('[data-wish]');
    if (w) {
      e.preventDefault();
      if (!logged) { location.href = base + '/login.php'; return; }
      toggleWish(w);
      return;
    }
    // Tombol − / + jumlah di keranjang
    var s = e.target.closest('[data-step]');
    if (s) {
      var form = s.closest('form');
      var input = form.querySelector('input[name=quantity]');
      var min = parseInt(input.min, 10) || 1;
      var max = parseInt(input.max, 10) || 999;
      var next = Math.min(max, Math.max(min, (parseInt(input.value, 10) || min) + parseInt(s.dataset.step, 10)));
      if (next !== parseInt(input.value, 10)) { input.value = next; form.submit(); }
    }
  });

  document.addEventListener('change', function (e) {
    if (e.target.matches('.qty input')) e.target.form.submit();
  });

  // Pesan sukses hilang sendiri
  document.querySelectorAll('[data-autohide]').forEach(function (el) {
    setTimeout(function () { el.remove(); }, 3500);
  });
})();
