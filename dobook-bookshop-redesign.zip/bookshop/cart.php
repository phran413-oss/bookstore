<?php
require_once 'config.php';
require_login();

$userId = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $bookId = (int)($_POST['book_id'] ?? 0);

    if ($action === 'add') {
        $stmt = $pdo->prepare("SELECT stock FROM books WHERE id = ?");
        $stmt->execute([$bookId]);
        $book = $stmt->fetch();

        if ($book && $book['stock'] > 0) {
            $stmt = $pdo->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND book_id = ?");
            $stmt->execute([$userId, $bookId]);
            $existing = $stmt->fetch();

            if ($existing) {
                $newQty = min($existing['quantity'] + 1, $book['stock']);
                $pdo->prepare("UPDATE cart SET quantity = ? WHERE id = ?")->execute([$newQty, $existing['id']]);
            } else {
                $pdo->prepare("INSERT INTO cart (user_id, book_id, quantity) VALUES (?,?,1)")->execute([$userId, $bookId]);
            }
            flash('success', 'Buku ditambahkan ke keranjang.');
        } else {
            flash('error', 'Stok buku habis.');
        }
    } elseif ($action === 'update') {
        $qty = max(1, (int)($_POST['quantity'] ?? 1));
        $stmt = $pdo->prepare("SELECT stock FROM books WHERE id = ?");
        $stmt->execute([$bookId]);
        $book = $stmt->fetch();
        if ($book) {
            $qty = min($qty, $book['stock']);
            $pdo->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND book_id = ?")->execute([$qty, $userId, $bookId]);
        }
    } elseif ($action === 'remove') {
        $pdo->prepare("DELETE FROM cart WHERE user_id = ? AND book_id = ?")->execute([$userId, $bookId]);
    }

    header('Location: ' . BASE_URL . '/cart.php');
    exit;
}

$stmt = $pdo->prepare("SELECT c.quantity, b.* FROM cart c JOIN books b ON c.book_id = b.id WHERE c.user_id = ? ORDER BY c.created_at DESC");
$stmt->execute([$userId]);
$items = $stmt->fetchAll();

$subtotal = 0;
foreach ($items as $it) {
    $subtotal += final_price($it['price'], $it['discount_percent']) * $it['quantity'];
}
$shipping = $subtotal > 0 ? 15000 : 0;
$grandTotal = $subtotal + $shipping;

$page_title = 'Keranjang';
require_once 'includes/header.php';
?>

<div class="page-head">
  <ol class="steps" aria-label="Langkah belanja"><li class="on">Keranjang</li><li>Checkout</li><li>Struk</li></ol>
  <h1 style="margin-top:14px;">Keranjang belanja</h1>
</div>

<?php if (empty($items)): ?>
  <div class="empty">
    <p>Keranjangmu masih kosong.</p>
    <a href="<?= BASE_URL ?>/category.php" class="btn btn-primary">Mulai belanja</a>
  </div>
<?php else: ?>
<div class="cart-layout">
  <div class="lines">
    <?php foreach ($items as $it): $fp = final_price($it['price'], $it['discount_percent']); ?>
    <div class="line">
      <a class="cover" href="<?= BASE_URL ?>/book_detail.php?id=<?= $it['id'] ?>"><img src="<?= book_image_url($it['image']) ?>" alt=""></a>
      <div class="info">
        <a class="line-title" href="<?= BASE_URL ?>/book_detail.php?id=<?= $it['id'] ?>"><?= htmlspecialchars($it['title']) ?></a>
        <div class="book-author" style="margin:0;"><?= htmlspecialchars($it['author']) ?> &middot; <?= rupiah($fp) ?></div>
      </div>
      <form method="post" class="qty">
        <input type="hidden" name="book_id" value="<?= $it['id'] ?>">
        <input type="hidden" name="action" value="update">
        <button type="button" data-step="-1" aria-label="Kurangi jumlah">&minus;</button>
        <input type="number" name="quantity" value="<?= $it['quantity'] ?>" min="1" max="<?= $it['stock'] ?>" aria-label="Jumlah">
        <button type="button" data-step="1" aria-label="Tambah jumlah">+</button>
        <noscript><button type="submit">OK</button></noscript>
      </form>
      <div class="sub"><?= rupiah($fp * $it['quantity']) ?></div>
      <form method="post">
        <input type="hidden" name="book_id" value="<?= $it['id'] ?>">
        <input type="hidden" name="action" value="remove">
        <button type="submit" class="icon-del" aria-label="Hapus <?= htmlspecialchars($it['title']) ?>"><?= icon('trash') ?></button>
      </form>
    </div>
    <?php endforeach; ?>
  </div>

  <aside class="panel summary">
    <h2>Ringkasan pesanan</h2>
    <div class="row"><span>Subtotal</span><span><?= rupiah($subtotal) ?></span></div>
    <div class="row"><span>Ongkos kirim</span><span><?= rupiah($shipping) ?></span></div>
    <div class="row total"><span>Total</span><span><?= rupiah($grandTotal) ?></span></div>
    <a href="<?= BASE_URL ?>/checkout.php" class="btn btn-primary btn-block">Lanjut ke checkout</a>
  </aside>
</div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
