<?php
require_once 'config.php';

$msg = [];

// cek apakah akun admin demo sudah ada
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute(['admin@bookshop.com']);
if (!$stmt->fetch()) {
    $hash = password_hash('admin123', PASSWORD_BCRYPT);
    $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?,?,?,'admin')")
        ->execute(['Admin Bookshop', 'admin@bookshop.com', $hash]);
    $msg[] = "Akun ADMIN berhasil dibuat: admin@bookshop.com / admin123";
} else {
    $msg[] = "Akun admin@bookshop.com sudah ada, dilewati.";
}

$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute(['user@bookshop.com']);
if (!$stmt->fetch()) {
    $hash = password_hash('user123', PASSWORD_BCRYPT);
    $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?,?,?,'user')")
        ->execute(['User Demo', 'user@bookshop.com', $hash]);
    $msg[] = "Akun USER berhasil dibuat: user@bookshop.com / user123";
} else {
    $msg[] = "Akun user@bookshop.com sudah ada, dilewati.";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Setup Akun Demo - Bookshop</title>
<style>
body{font-family:Arial,sans-serif;max-width:600px;margin:60px auto;padding:0 20px;color:#222}
.box{border:1px solid #ddd;border-radius:8px;padding:24px}
h1{font-size:20px}
li{margin-bottom:8px}
a{display:inline-block;margin-top:16px;background:#111;color:#fff;padding:10px 18px;border-radius:6px;text-decoration:none}
.warn{background:#fff8e1;border:1px solid #ffe08a;padding:10px;border-radius:6px;font-size:14px;margin-top:16px}
</style>
</head>
<body>
<div class="box">
<h1>Setup Akun Demo Bookshop</h1>
<ul>
<?php foreach ($msg as $m) echo "<li>$m</li>"; ?>
</ul>
<div class="warn">Hapus atau pindahkan file <code>setup.php</code> ini setelah selesai digunakan, supaya tidak bisa diakses orang lain.</div>
<a href="<?= BASE_URL ?>/login.php">Lanjut ke halaman Login</a>
</div>
</body>
</html>
