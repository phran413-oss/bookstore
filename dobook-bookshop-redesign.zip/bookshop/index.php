<?php
require_once 'config.php';

$wishIds = wish_ids($pdo);

function fetch_section($pdo, $section, $limit = 6) {
    $limit = (int)$limit;
    $stmt = $pdo->prepare("SELECT * FROM books WHERE section = ? ORDER BY created_at DESC LIMIT $limit");
    $stmt->execute([$section]);
    return $stmt->fetchAll();
}

$newBooks = fetch_section($pdo, 'new');
$bestSellers = fetch_section($pdo, 'bestseller');
$trending = fetch_section($pdo, 'trending');

// buku unggulan untuk hero (diskon terbesar)
$stmt = $pdo->query("SELECT * FROM books WHERE discount_percent > 0 ORDER BY discount_percent DESC LIMIT 1");
$bannerBook = $stmt->fetch();
if (!$bannerBook) {
    $stmt = $pdo->query("SELECT * FROM books ORDER BY created_at DESC LIMIT 1");
    $bannerBook = $stmt->fetch();
}

function render_book_row($books, $wishIds, $class = 'book-grid') {
    if (empty($books)) {
        echo '<div class="empty"><p>Belum ada buku di bagian ini.</p></div>';
        return;
    }
    echo '<div class="' . $class . '">';
    foreach ($books as $b) render_book_card($b, $wishIds);
    echo '</div>';
}

$page_title = 'Home';
require_once 'includes/header.php';
?>

<section class="hero">
  <div>
    <h1>Bacaan berikutnya ada di sini.</h1>
    <p>Novel, pengembangan diri, dan buku populer lainnya. Pesan hari ini, kami antar ke rumahmu.</p>
    <div class="hero-cta">
      <a href="<?= BASE_URL ?>/category.php" class="btn btn-primary">Lihat semua buku</a>
      <?php if (is_logged_in()): ?>
        <a href="<?= BASE_URL ?>/wishlist.php" class="btn btn-outline">Buka wishlist</a>
      <?php else: ?>
        <a href="<?= BASE_URL ?>/register.php" class="btn btn-outline">Buat akun</a>
      <?php endif; ?>
    </div>
  </div>

  <?php if ($bannerBook): $fp = final_price($bannerBook['price'], $bannerBook['discount_percent']); ?>
  <div class="hero-art">
    <div class="arch">
      <img src="<?= book_image_url($bannerBook['image']) ?>" alt="Sampul <?= htmlspecialchars($bannerBook['title']) ?>">
      <div class="sticker">
        <?php if ($bannerBook['discount_percent'] > 0): ?>
          <span>Diskon<b><?= (int)$bannerBook['discount_percent'] ?>%</b></span>
        <?php else: ?>
          <b>Baru</b>
        <?php endif; ?>
      </div>
    </div>
    <div class="hero-cap">
      <h2><?= htmlspecialchars($bannerBook['title']) ?></h2>
      <p class="muted"><?= htmlspecialchars($bannerBook['author']) ?> &middot; <?= rupiah($fp) ?></p>
      <a href="<?= BASE_URL ?>/book_detail.php?id=<?= $bannerBook['id'] ?>">Lihat buku ini</a>
    </div>
  </div>
  <?php endif; ?>
</section>

<section>
  <div class="sec-head"><h2>What's new</h2><a href="<?= BASE_URL ?>/category.php">Semua buku</a></div>
  <?php render_book_row($newBooks, $wishIds); ?>
</section>

<section>
  <div class="sec-head"><h2>Best seller</h2></div>
  <?php if (empty($bestSellers)): ?>
    <div class="empty"><p>Belum ada buku di bagian ini.</p></div>
  <?php else: ?>
  <ol class="rank">
    <?php foreach ($bestSellers as $i => $b): $fp = final_price($b['price'], $b['discount_percent']); $url = BASE_URL . '/book_detail.php?id=' . $b['id']; ?>
    <li>
      <span class="rank-no"><?= $i + 1 ?></span>
      <a class="cover" href="<?= $url ?>"><img src="<?= book_image_url($b['image']) ?>" alt="Sampul <?= htmlspecialchars($b['title']) ?>" loading="lazy"></a>
      <div>
        <a class="book-title" href="<?= $url ?>"><?= htmlspecialchars($b['title']) ?></a>
        <p class="book-author"><?= htmlspecialchars($b['author']) ?></p>
        <div class="price"><strong><?= rupiah($fp) ?></strong><?php if ($b['discount_percent'] > 0): ?><s><?= rupiah($b['price']) ?></s><?php endif; ?></div>
      </div>
      <form method="post" action="<?= BASE_URL ?>/cart.php">
        <input type="hidden" name="book_id" value="<?= $b['id'] ?>">
        <input type="hidden" name="action" value="add">
        <button type="submit" class="btn-icon" aria-label="Tambah <?= htmlspecialchars($b['title']) ?> ke keranjang" <?= $b['stock'] <= 0 ? 'disabled' : '' ?>><?= icon('plus') ?></button>
      </form>
    </li>
    <?php endforeach; ?>
  </ol>
  <?php endif; ?>
</section>

<section>
  <div class="sec-head"><h2>Trending now</h2></div>
  <?php render_book_row($trending, $wishIds, 'scroller'); ?>
</section>

<?php require_once 'includes/footer.php'; ?>
