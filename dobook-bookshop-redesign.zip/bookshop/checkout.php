<?php
require_once 'config.php';
require_login();

$userId = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT c.quantity, b.* FROM cart c JOIN books b ON c.book_id = b.id WHERE c.user_id = ?");
$stmt->execute([$userId]);
$items = $stmt->fetchAll();

if (empty($items)) {
    header('Location: ' . BASE_URL . '/cart.php');
    exit;
}

$subtotal = 0;
foreach ($items as $it) {
    $subtotal += final_price($it['price'], $it['discount_percent']) * $it['quantity'];
}
$shipping = 15000;
$grandTotal = $subtotal + $shipping;

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payment = $_POST['payment_method'] ?? 'Transfer Bank';

    // cek stok sekali lagi sebelum commit transaksi
    $outOfStock = [];
    foreach ($items as $it) {
        if ($it['quantity'] > $it['stock']) {
            $outOfStock[] = $it['title'];
        }
    }

    if (!empty($outOfStock)) {
        $error = 'Stok tidak cukup untuk: ' . implode(', ', $outOfStock);
    } else {
        try {
            $pdo->beginTransaction();

            $receiptNo = 'INV-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));

            $stmt = $pdo->prepare("INSERT INTO orders (receipt_no, user_id, total, payment_method, status) VALUES (?,?,?,?,'paid')");
            $stmt->execute([$receiptNo, $userId, $grandTotal, $payment]);
            $orderId = $pdo->lastInsertId();

            foreach ($items as $it) {
                $fp = final_price($it['price'], $it['discount_percent']);
                $stmt = $pdo->prepare("INSERT INTO order_items (order_id, book_id, title, price, quantity, subtotal) VALUES (?,?,?,?,?,?)");
                $stmt->execute([$orderId, $it['id'], $it['title'], $fp, $it['quantity'], $fp * $it['quantity']]);

                $pdo->prepare("UPDATE books SET stock = stock - ? WHERE id = ?")->execute([$it['quantity'], $it['id']]);
            }

            $pdo->prepare("DELETE FROM cart WHERE user_id = ?")->execute([$userId]);

            $pdo->commit();

            header('Location: ' . BASE_URL . '/receipt.php?order_id=' . $orderId);
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = 'Transaksi gagal, silakan coba lagi.';
        }
    }
}

$stmt = $pdo->prepare("SELECT name, email FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

$page_title = 'Checkout';
require_once 'includes/header.php';
?>

<div class="page-head">
  <ol class="steps" aria-label="Langkah belanja"><li class="done">Keranjang</li><li class="on">Checkout</li><li>Struk</li></ol>
  <h1 style="margin-top:14px;">Checkout</h1>
</div>

<?php if ($error): ?>
  <div class="alert alert-error" role="alert"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="post" class="cart-layout">
  <div class="stack">
    <div class="panel">
      <h2>Penerima</h2>
      <strong><?= htmlspecialchars($user['name']) ?></strong>
      <div class="muted"><?= htmlspecialchars($user['email']) ?></div>
    </div>

    <div class="panel">
      <h2>Metode pembayaran</h2>
      <label class="choice"><input type="radio" name="payment_method" value="Transfer Bank" checked>Transfer Bank</label>
      <label class="choice"><input type="radio" name="payment_method" value="E-Wallet">E-Wallet</label>
      <label class="choice"><input type="radio" name="payment_method" value="Bayar di Tempat (COD)">Bayar di Tempat (COD)</label>
    </div>

    <div class="panel">
      <h2>Item pesanan</h2>
      <ul class="mini-items">
        <?php foreach ($items as $it): $fp = final_price($it['price'], $it['discount_percent']); ?>
          <li><span><?= htmlspecialchars($it['title']) ?> &times; <?= $it['quantity'] ?></span><span><?= rupiah($fp * $it['quantity']) ?></span></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>

  <aside class="panel summary">
    <h2>Total pembayaran</h2>
    <div class="row"><span>Subtotal</span><span><?= rupiah($subtotal) ?></span></div>
    <div class="row"><span>Ongkos kirim</span><span><?= rupiah($shipping) ?></span></div>
    <div class="row total"><span>Total</span><span><?= rupiah($grandTotal) ?></span></div>
    <button type="submit" class="btn btn-primary btn-block">Bayar sekarang</button>
  </aside>
</form>

<?php require_once 'includes/footer.php'; ?>
