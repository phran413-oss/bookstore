<?php
require_once '../config.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newStatus = $_POST['status'] ?? '';
    $allowed = ['pending','paid','shipped','completed','cancelled'];
    if (in_array($newStatus, $allowed)) {
        $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?")->execute([$newStatus, $id]);
        flash('success', 'Status pesanan diperbarui.');
    }
    header('Location: ' . BASE_URL . '/admin/order_detail.php?id=' . $id);
    exit;
}

$stmt = $pdo->prepare("SELECT o.*, u.name AS customer, u.email FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?");
$stmt->execute([$id]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: ' . BASE_URL . '/admin/orders.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
$stmt->execute([$id]);
$items = $stmt->fetchAll();

$page_title = 'Detail Pesanan';
require_once 'includes/header.php';
?>

<h1>Detail Pesanan #<?= htmlspecialchars($order['receipt_no']) ?></h1>

<div style="display:flex;gap:20px;flex-wrap:wrap;">
  <div style="flex:2;min-width:300px;">
    <table class="data-table" style="margin-bottom:20px;">
      <thead><tr><th>Buku</th><th>Harga</th><th>Qty</th><th>Subtotal</th></tr></thead>
      <tbody>
      <?php foreach ($items as $it): ?>
        <tr>
          <td><?= htmlspecialchars($it['title']) ?></td>
          <td><?= rupiah($it['price']) ?></td>
          <td><?= $it['quantity'] ?></td>
          <td><?= rupiah($it['subtotal']) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <a href="<?= BASE_URL ?>/receipt.php?order_id=<?= $order['id'] ?>" class="btn btn-outline" target="_blank">Lihat Struk</a>
  </div>

  <div style="flex:1;min-width:260px;">
    <div class="cart-summary" style="margin-bottom:16px;">
      <h3 style="margin-top:0;">Informasi</h3>
      <p><strong>Customer:</strong> <?= htmlspecialchars($order['customer']) ?></p>
      <p><strong>Email:</strong> <?= htmlspecialchars($order['email']) ?></p>
      <p><strong>Tanggal:</strong> <?= date('d M Y, H:i', strtotime($order['order_date'])) ?></p>
      <p><strong>Pembayaran:</strong> <?= htmlspecialchars($order['payment_method']) ?></p>
      <p><strong>Total:</strong> <?= rupiah($order['total']) ?></p>
    </div>

    <form method="post" class="cart-summary">
      <h3 style="margin-top:0;">Update Status</h3>
      <div class="form-group">
        <select name="status">
          <?php foreach (['pending','paid','shipped','completed','cancelled'] as $s): ?>
            <option value="<?= $s ?>" <?= $order['status'] === $s ? 'selected' : '' ?>><?= status_label($s) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <button type="submit" class="btn btn-primary btn-block">Simpan Status</button>
    </form>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
