# DOBOOK - Website Toko Buku (PHP + MySQL + XAMPP)

Website toko buku sederhana dengan 2 role akun (Admin & User), fitur wishlist,
keranjang belanja, checkout, sampai struk/resi transaksi.

## 📁 Struktur Folder
```
bookshop/
├── admin/              -> semua halaman khusus admin
├── assets/css/         -> style.css (tampilan sesuai mockup)
├── assets/images/      -> gambar, termasuk uploads/ untuk cover buku
├── includes/           -> header & footer yang dipakai halaman user
├── config.php          -> koneksi database & fungsi helper
├── database.sql        -> struktur + data awal database
├── setup.php           -> membuat akun demo admin & user (jalankan sekali)
├── index.php           -> Home
├── login.php / register.php / logout.php
├── category.php        -> daftar buku / pencarian / filter kategori
├── book_detail.php
├── wishlist.php
├── cart.php
├── checkout.php
├── receipt.php         -> struk/resi setelah checkout
└── orders.php          -> riwayat pesanan user
```

## 🚀 Cara Instalasi di XAMPP

1. **Copy folder project**
   Salin seluruh folder `bookshop` ini ke dalam folder `htdocs` XAMPP kamu, contoh:
   `C:\xampp\htdocs\bookshop`

2. **Jalankan Apache & MySQL**
   Buka XAMPP Control Panel, klik **Start** pada Apache dan MySQL.

3. **Buat database**
   - Buka `http://localhost/phpmyadmin`
   - Klik tab **Import**
   - Pilih file `database.sql` dari folder project, lalu klik **Go**
   - Database `bookshop` beserta tabel dan contoh buku akan otomatis dibuat

4. **Cek konfigurasi**
   Buka file `config.php`, pastikan bagian ini sesuai dengan XAMPP kamu (default XAMPP biasanya sudah pas, tidak perlu diubah):
   ```php
   $DB_HOST = 'localhost';
   $DB_NAME = 'bookshop';
   $DB_USER = 'root';
   $DB_PASS = '';
   ```
   Jika nama folder project kamu di `htdocs` BUKAN `bookshop`, ubah baris ini juga:
   ```php
   define('BASE_URL', '/bookshop'); // ganti sesuai nama folder kamu
   ```

5. **Buat akun demo**
   Buka di browser: `http://localhost/bookshop/setup.php`
   Ini akan otomatis membuat 2 akun:
   - **Admin** → email: `admin@bookshop.com` — password: `admin123`
   - **User** → email: `user@bookshop.com` — password: `user123`

   Setelah itu, sebaiknya hapus file `setup.php` supaya tidak bisa diakses orang lain.

6. **Buka website**
   `http://localhost/bookshop/index.php`

## 👤 Cara Jadi Admin
Cukup **login** menggunakan akun yang rolenya `admin` (contoh: `admin@bookshop.com`).
Setelah login, menu **🛠 Admin** akan muncul di pojok kanan atas untuk masuk ke
panel admin (`/admin/index.php`) — di situ admin bisa:
- Tambah / edit / hapus buku (termasuk upload cover, atur diskon, stok, dan
  section tampilan di beranda: What's New / Best Seller / Trending)
- Melihat semua transaksi & mengubah status pesanan (pending → paid → shipped → completed)
- Melihat statistik ringkas (total buku, user, transaksi, pendapatan)

Akun dengan role `user` (hasil daftar lewat `register.php`) hanya bisa belanja
seperti biasa: cari buku, wishlist, tambah ke keranjang, checkout, dan melihat
struk/riwayat pesanan — tidak bisa mengakses halaman admin.

## 🛒 Alur Transaksi User
1. User login / daftar akun baru
2. Cari buku lewat search bar atau menu **Books** (bisa filter kategori)
3. Klik ♡ untuk simpan ke **Wishlist**, atau **+ Add to Cart**
4. Buka halaman **Cart**, atur jumlah, lalu klik **Checkout**
5. Pilih metode pembayaran, klik **Bayar Sekarang**
6. Sistem otomatis membuat nomor invoice, mengurangi stok buku, dan menampilkan
   halaman **struk/resi** (bisa langsung dicetak / print)
7. Semua pesanan bisa dilihat lagi di menu **🧾 Pesanan**

## ⚠️ Catatan
- Pastikan folder `assets/images/uploads/` memiliki izin tulis (writable) agar
  admin bisa upload cover buku.
- Password disimpan ter-enkripsi (bcrypt) menggunakan `password_hash()` PHP,
  bukan teks biasa.
- Ini adalah project belajar/demo — untuk produksi sebaiknya tambahkan validasi
  & keamanan tambahan (rate limiting, HTTPS, dsb).
