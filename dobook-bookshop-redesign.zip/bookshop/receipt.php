<?php
require_once 'config.php';
require_login();

$orderId = (int)($_GET['order_id'] ?? 0);

$stmt = $pdo->prepare("SELECT o.*, u.name AS customer_name, u.email FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?");
$stmt->execute([$orderId]);
$order = $stmt->fetch();

if (!$order || ($order['user_id'] != $_SESSION['user_id'] && !is_admin())) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
$stmt->execute([$orderId]);
$items = $stmt->fetchAll();

$subtotal = array_sum(array_column($items, 'subtotal'));
$shipping = $order['total'] - $subtotal;

$page_title = 'Struk Pembayaran';
require_once 'includes/header.php';
?>

<div class="page-head no-print">
  <ol class="steps" aria-label="Langkah belanja"><li class="done">Keranjang</li><li class="done">Checkout</li><li class="on">Struk</li></ol>
</div>

<div class="receipt-wrap">
  <div class="receipt">
    <h2><?= SITE_NAME ?></h2>
    <p class="center">Bukti pembayaran</p>
    <hr>
    <table>
      <tr><td>No. Invoice</td><td class="r"><?= htmlspecialchars($order['receipt_no']) ?></td></tr>
      <tr><td>Tanggal</td><td class="r"><?= date('d M Y, H:i', strtotime($order['order_date'])) ?></td></tr>
      <tr><td>Pelanggan</td><td class="r"><?= htmlspecialchars($order['customer_name']) ?></td></tr>
      <tr><td>Pembayaran</td><td class="r"><?= htmlspecialchars($order['payment_method']) ?></td></tr>
    </table>
    <hr>
    <table>
      <?php foreach ($items as $it): ?>
        <tr><td colspan="2"><?= htmlspecialchars($it['title']) ?></td></tr>
        <tr><td><?= $it['quantity'] ?> x <?= rupiah($it['price']) ?></td><td class="r"><?= rupiah($it['subtotal']) ?></td></tr>
      <?php endforeach; ?>
    </table>
    <hr>
    <table>
      <tr><td>Subtotal</td><td class="r"><?= rupiah($subtotal) ?></td></tr>
      <tr><td>Ongkos kirim</td><td class="r"><?= rupiah($shipping) ?></td></tr>
      <tr class="grand"><td>TOTAL</td><td class="r"><?= rupiah($order['total']) ?></td></tr>
    </table>
    <hr>
    <div class="stamp-wrap"><span class="stamp"><?= status_label($order['status']) ?></span></div>
    <p class="center" style="margin-top:14px;">Terima kasih telah berbelanja di <?= SITE_NAME ?>!</p>
  </div>
</div>

<div class="receipt-actions no-print">
  <button type="button" class="btn btn-primary" onclick="window.print()"><?= icon('printer') ?>Cetak struk</button>
  <a href="<?= BASE_URL ?>/orders.php" class="btn btn-outline">Lihat semua pesanan</a>
</div>

<?php require_once 'includes/footer.php'; ?>
