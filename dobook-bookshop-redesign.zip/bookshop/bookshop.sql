-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 03, 2026 at 03:13 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `author` varchar(150) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `price` decimal(12,2) NOT NULL,
  `discount_percent` int(11) DEFAULT 0,
  `stock` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT 'no-image.png',
  `section` enum('new','bestseller','trending','none') DEFAULT 'none',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `category_id`, `price`, `discount_percent`, `stock`, `description`, `image`, `section`, `created_at`) VALUES
(1, 'Psychology of money', 'morgan housel', NULL, 90000.00, 30, 45, '', 'book_1785976051_9236.webp', 'new', '2026-08-06 00:27:31'),
(2, 'The let them theory', 'mel robbins', NULL, 120000.00, 10, 30, '', 'book_1785976980_1343.jpg', 'bestseller', '2026-08-06 00:43:00'),
(3, 'Educated', 'Tara westover', NULL, 200000.00, 15, 50, '', 'book_1785977200_8058.jpg', 'trending', '2026-08-06 00:46:40'),
(4, 'Melangkah', 'JS kharen', NULL, 99000.00, 0, 30, '', 'book_1785977522_6791.jpg', 'bestseller', '2026-08-06 00:52:02'),
(5, 'Keajaiban toko kelontong namiya', 'Keigo higashino', NULL, 100000.00, 10, 25, '', 'book_1785977768_5201.jpg', 'trending', '2026-08-06 00:56:08'),
(6, 'The midnight library', 'Matt haig', NULL, 85000.00, 0, 40, '', 'book_1785977973_7941.jpg', 'new', '2026-08-06 00:59:33'),
(7, 'Nebula', 'Tere liye', NULL, 109000.00, 0, 40, '', 'book_1785978396_8111.jpg', 'new', '2026-08-06 01:06:36'),
(8, 'Selena', 'Tere liye', NULL, 109000.00, 0, 35, '', 'book_1785978484_1591.jpg', 'bestseller', '2026-08-06 01:08:04'),
(9, 'Selamat tinggal', 'Tere liye', NULL, 99000.00, 5, 30, '', 'book_1785978588_4521.jpg', 'trending', '2026-08-06 01:09:48'),
(10, 'Brianna dan bottomwise', 'Andrea hirata', NULL, 115000.00, 7, 45, '', 'book_1785978774_7814.jpeg', 'bestseller', '2026-08-06 01:12:54'),
(11, 'Filosofi teras', 'Henry manampiring', NULL, 110000.00, 5, 25, '', 'book_1785979228_7277.jpg', 'new', '2026-08-06 01:20:28'),
(12, 'Berani tidak disukai', 'Ichiro kishimi & Fumitake koga', NULL, 105000.00, 10, 15, '', 'book_1785979396_5663.jpg', 'bestseller', '2026-08-06 01:23:16'),
(13, 'Sebuah seni untuk bersikap bodo amat', 'Mark manson', NULL, 88000.00, 12, 35, '', 'book_1785979483_5620.jpg', 'trending', '2026-08-06 01:24:43'),
(14, 'Bicara itu ada seninya', 'Oh su hyang', NULL, 95000.00, 5, 30, '', 'book_1785979585_5165.jpg', 'trending', '2026-08-06 01:26:25'),
(15, 'Grit: kekuatan passion dan kegigihan', 'Angela duckworth', NULL, 130000.00, 10, 45, '', 'book_1785979699_8591.jpg', 'new', '2026-08-06 01:28:19'),
(16, 'Laskar Pelangi', 'Andrea hirata', NULL, 95000.00, 5, 35, '', 'book_1785979962_3044.jpg', 'new', '2026-08-06 01:32:42'),
(17, 'Alchemist', 'Paulo coelho', NULL, 80000.00, 15, 65, '', 'book_1785980041_3485.jpg', 'bestseller', '2026-08-06 01:34:01'),
(18, 'Zero to one', 'Peter thiel', NULL, 98000.00, 10, 50, '', 'book_1785980108_5376.jpg', 'trending', '2026-08-06 01:35:08');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `receipt_no` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `payment_method` varchar(50) DEFAULT 'Transfer Bank',
  `status` enum('pending','paid','shipped','completed','cancelled') DEFAULT 'paid',
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'Admin Bookshop', 'admin@bookshop.com', '$2y$10$m5Gr7DNX9X8G4MaNN2jAMOibGsNuR09/JlmKQgvnz94Jcgtv0mjn2', 'admin', '2026-08-06 00:11:45'),
(2, 'User Demo', 'user@bookshop.com', '$2y$10$0CVrjSIqdnoI5AXSz/gW0.nLo9RbboUcOg7iQRlGks5H5jWafe.eC', 'user', '2026-08-06 00:11:45'),
(3, 'ridho', 'phran413@gmail.com', '$2y$10$WMKbI.EfkMyaaDrspYH.H.W0z4fcZD8vwnuxOviQ3hgOR2oGbOEVG', 'user', '2026-08-06 00:13:06');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_cart` (`user_id`,`book_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `receipt_no` (`receipt_no`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_wish` (`user_id`,`book_id`),
  ADD KEY `book_id` (`book_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `books_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
