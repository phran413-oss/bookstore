<?php
require_once 'config.php';

$catId = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;
$q = trim($_GET['q'] ?? '');

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();

$sql = "SELECT * FROM books WHERE 1=1";
$params = [];
if ($catId > 0) {
    $sql .= " AND category_id = ?";
    $params[] = $catId;
}
if ($q !== '') {
    $sql .= " AND (title LIKE ? OR author LIKE ?)";
    $params[] = "%$q%";
    $params[] = "%$q%";
}
$sql .= " ORDER BY created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

$wishIds = wish_ids($pdo);

$page_title = 'Books';
require_once 'includes/header.php';
?>

<div class="page-head">
  <h1><?= $q !== '' ? 'Hasil untuk "' . htmlspecialchars($q) . '"' : 'Semua Buku' ?></h1>
  <p><?= count($books) ?> buku ditemukan</p>
</div>

<div class="tabs">
  <a href="<?= BASE_URL ?>/category.php<?= $q !== '' ? '?q=' . urlencode($q) : '' ?>" class="<?= $catId === 0 ? 'active' : '' ?>">Semua</a>
  <?php foreach ($categories as $c): ?>
    <a href="<?= BASE_URL ?>/category.php?cat=<?= $c['id'] ?><?= $q !== '' ? '&q=' . urlencode($q) : '' ?>" class="<?= $catId === (int)$c['id'] ? 'active' : '' ?>"><?= htmlspecialchars($c['name']) ?></a>
  <?php endforeach; ?>
</div>

<?php if (empty($books)): ?>
  <div class="empty">
    <p>Buku tidak ditemukan. Coba kata kunci lain atau lihat semua buku.</p>
    <a href="<?= BASE_URL ?>/category.php" class="btn btn-outline">Lihat semua buku</a>
  </div>
<?php else: ?>
  <div class="book-grid">
    <?php foreach ($books as $b) render_book_card($b, $wishIds); ?>
  </div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
