<?php
// ==========================================
// terms-of-service.php - Halaman statis
// ==========================================
require_once 'includes/init.php';

$judul_halaman = 'Terms of Service';
$tampilkan_search = false;
include 'includes/header.php';
?>

    <section class="static-page-section">
        <h1>Terms of Service</h1>
        <p class="static-updated">Terakhir diperbarui: <?php echo date('d F Y'); ?></p>

        <h3>1. Penerimaan Ketentuan</h3>
        <p>Dengan menggunakan Bookstore, kamu setuju untuk mematuhi seluruh ketentuan layanan yang tercantum di halaman ini.</p>

        <h3>2. Akun Pengguna</h3>
        <p>Kamu bertanggung jawab menjaga kerahasiaan password akun kamu. Segala aktivitas yang terjadi di bawah akun kamu menjadi tanggung jawab kamu sepenuhnya.</p>

        <h3>3. Pemesanan & Pembayaran</h3>
        <p>Seluruh pesanan yang masuk akan diproses oleh admin setelah pembayaran dikonfirmasi. Harga dan ketersediaan stok dapat berubah sewaktu-waktu.</p>

        <h3>4. Pembatalan Pesanan</h3>
        <p>Bookstore berhak membatalkan pesanan apabila terjadi kendala stok atau kesalahan sistem, dengan pemberitahuan kepada pembeli.</p>

        <p class="static-note">
            Catatan: Halaman ini adalah contoh placeholder untuk keperluan latihan/pengembangan, bukan kebijakan privasi yang berlaku secara hukum.
        </p>
    </section>

<?php include 'includes/footer.php'; ?>
