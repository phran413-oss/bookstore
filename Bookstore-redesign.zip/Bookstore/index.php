<?php
// ==========================================
// index.php - Halaman Home
// ==========================================
require_once 'includes/init.php';

// Satu fungsi kecil buat ambil buku per section (sebelumnya query-nya ditulis 3x)
function ambil_buku($conn, $kondisi)
{
    return mysqli_query($conn, "SELECT * FROM books WHERE $kondisi");
}

// "What's new" otomatis: buku yang ditambahin dalam 7 hari terakhir
$sections = [
    "What's new?"  => ambil_buku($conn, "created_at >= NOW() - INTERVAL 7 DAY ORDER BY created_at DESC"),
    "Best seller"  => ambil_buku($conn, "is_bestseller = 1"),
    "Trending now" => ambil_buku($conn, "is_trending = 1"),
];

// Cover buat hiasan hero (3 buku, utamakan best seller)
$hero_covers = [];
$q_hero = mysqli_query($conn, "SELECT * FROM books WHERE cover_image IS NOT NULL AND cover_image <> '' ORDER BY is_bestseller DESC, id DESC LIMIT 3");
while ($b = mysqli_fetch_assoc($q_hero)) {
    $hero_covers[] = $b;
}

$judul_halaman = null;
include 'includes/header.php';
?>

    <section class="hero">
        <div class="hero-text">
            <span class="hero-eyebrow">Toko buku online</span>
            <h1>Temukan bacaan berikutnya yang <em>susah diletakkan.</em></h1>
            <p class="hero-sub">Dari fiksi sampai pengembangan diri, semua ada di satu rak. Pilih, bayar, dan buku sampai di rumahmu.</p>
            <div class="hero-cta">
                <a href="books.php" class="hero-btn primary">Jelajahi genre</a>
                <a href="#best-seller" class="hero-btn ghost">Lihat best seller</a>
            </div>
        </div>
        <?php if (count($hero_covers) > 0) { ?>
            <div class="hero-art" aria-hidden="true">
                <?php foreach ($hero_covers as $b) { ?>
                    <img src="<?php echo e(cover_url($b)); ?>" alt="">
                <?php } ?>
            </div>
        <?php } ?>
    </section>

    <?php foreach ($sections as $judul => $result) { ?>
        <section class="book-section" id="<?php echo e(trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($judul)), '-')); ?>">
            <h2><?php echo e($judul); ?></h2>
            <div class="book-wrapper">
                <div class="book-list">
                    <?php if (mysqli_num_rows($result) == 0) { ?>
                        <p class="shelf-empty">Belum ada buku di rak ini.</p>
                    <?php } else {
                        while ($book = mysqli_fetch_assoc($result)) {
                            include 'includes/book_card.php';
                        }
                    } ?>
                </div>
            </div>
        </section>
    <?php } ?>

<?php include 'includes/footer.php'; ?>
