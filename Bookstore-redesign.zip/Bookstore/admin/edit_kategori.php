<?php
// ==========================================
// admin/edit_kategori.php - Edit kategori / sub-genre
// ==========================================
require_once '../includes/init.php';
wajib_admin();

$id = (int)($_GET['id'] ?? 0);
$error = "";

$stmt = mysqli_prepare($conn, "SELECT * FROM categories WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$kategori = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$kategori) {
    die("Kategori tidak ditemukan. <a href='kategori.php'>Kembali</a>");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_kategori = trim($_POST['nama_kategori']);
    $parent_id = $_POST['parent_id'] == '' ? null : (int)$_POST['parent_id'];

    if ($nama_kategori == '') {
        $error = "Nama kategori tidak boleh kosong.";
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE categories SET nama_kategori = ?, parent_id = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "sii", $nama_kategori, $parent_id, $id);
        mysqli_stmt_execute($stmt);
        header("Location: kategori.php");
        exit;
    }
}

// Pilihan "induk": kategori utama selain dirinya sendiri
$stmt = mysqli_prepare($conn, "SELECT * FROM categories WHERE parent_id IS NULL AND id != ? ORDER BY nama_kategori");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$kategori_utama = mysqli_stmt_get_result($stmt);

$judul_halaman = 'Edit Kategori';
include '../includes/admin_header.php';
?>

    <section class="admin-section">
        <h2>Edit Kategori: <?php echo e($kategori['nama_kategori']); ?></h2>
        <?php if ($error) { ?><p class="auth-error"><?php echo e($error); ?></p><?php } ?>

        <form method="POST" action="" class="admin-form">
            <label>Nama Kategori</label>
            <input type="text" name="nama_kategori" value="<?php echo e($kategori['nama_kategori']); ?>" required>

            <label>Induk Kategori</label>
            <select name="parent_id">
                <option value="">-- Jadikan Kategori Utama --</option>
                <?php while ($k = mysqli_fetch_assoc($kategori_utama)) { ?>
                    <option value="<?php echo (int)$k['id']; ?>" <?php echo ($k['id'] == $kategori['parent_id']) ? 'selected' : ''; ?>>
                        Sub-genre dari: <?php echo e($k['nama_kategori']); ?>
                    </option>
                <?php } ?>
            </select>

            <button type="submit">Simpan Perubahan</button>
        </form>
    </section>

<?php include '../includes/admin_footer.php'; ?>
