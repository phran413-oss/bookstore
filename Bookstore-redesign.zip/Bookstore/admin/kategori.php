<?php
// ==========================================
// admin/kategori.php - Kelola Kategori & Sub-Genre
// ==========================================
require_once '../includes/init.php';
wajib_admin();

$error = "";

// ---------- TAMBAH KATEGORI / SUB-GENRE ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_kategori = trim($_POST['nama_kategori']);
    // Kosong = kategori utama (parent_id NULL); diisi = sub-genre dari kategori itu
    $parent_id = $_POST['parent_id'] == '' ? null : (int)$_POST['parent_id'];

    if ($nama_kategori == '') {
        $error = "Nama kategori tidak boleh kosong.";
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO categories (nama_kategori, parent_id) VALUES (?, ?)");
        mysqli_stmt_bind_param($stmt, "si", $nama_kategori, $parent_id);
        mysqli_stmt_execute($stmt);
        header("Location: kategori.php");
        exit;
    }
}

// Ambil semua kategori sekali, lalu kelompokkan di PHP (nggak perlu query per kategori)
$kategori_utama = [];
$sub_genre = [];
$result = mysqli_query($conn, "SELECT * FROM categories ORDER BY nama_kategori");
while ($k = mysqli_fetch_assoc($result)) {
    if ($k['parent_id'] === null) {
        $kategori_utama[] = $k;
    } else {
        $sub_genre[$k['parent_id']][] = $k;
    }
}

$judul_halaman = 'Kategori';
include '../includes/admin_header.php';
?>

    <section class="admin-section">
        <h2>Kelola Kategori & Sub-Genre</h2>

        <div class="kategori-form-box">
            <h3>Tambah Baru</h3>
            <?php if ($error) { ?><p class="auth-error"><?php echo e($error); ?></p><?php } ?>

            <form method="POST" action="" class="admin-form kategori-inline-form">
                <input type="text" name="nama_kategori" placeholder="Nama kategori/sub-genre" required>
                <select name="parent_id">
                    <option value="">-- Jadikan Kategori Utama --</option>
                    <?php foreach ($kategori_utama as $k) { ?>
                        <option value="<?php echo (int)$k['id']; ?>">Sub-genre dari: <?php echo e($k['nama_kategori']); ?></option>
                    <?php } ?>
                </select>
                <button type="submit">+ Tambah</button>
            </form>
            <p class="form-hint">
                Kosongkan pilihan "induk" kalau mau bikin kategori utama baru (setara Fiksi/Non-Fiksi).
                Pilih salah satu kalau mau bikin sub-genre di dalamnya.
            </p>
        </div>

        <?php foreach ($kategori_utama as $main) { ?>
            <div class="kategori-group">
                <div class="kategori-group-header">
                    <h3>#<?php echo e($main['nama_kategori']); ?></h3>
                    <div class="kategori-actions">
                        <a href="edit_kategori.php?id=<?php echo (int)$main['id']; ?>" class="btn-edit">Edit</a>
                        <a href="hapus_kategori.php?id=<?php echo (int)$main['id']; ?>"
                           class="btn-delete"
                           onclick="return confirm('Hapus kategori ini? Sub-genre di dalamnya akan jadi kategori utama.');">Hapus</a>
                    </div>
                </div>
                <ul class="kategori-sub-list">
                    <?php if (empty($sub_genre[$main['id']])) { ?>
                        <li class="kategori-empty">Belum ada sub-genre.</li>
                    <?php } else {
                        foreach ($sub_genre[$main['id']] as $sub) { ?>
                            <li>
                                <span><?php echo e($sub['nama_kategori']); ?></span>
                                <div class="kategori-actions">
                                    <a href="edit_kategori.php?id=<?php echo (int)$sub['id']; ?>" class="btn-edit">Edit</a>
                                    <a href="hapus_kategori.php?id=<?php echo (int)$sub['id']; ?>"
                                       class="btn-delete"
                                       onclick="return confirm('Hapus sub-genre ini?');">Hapus</a>
                                </div>
                            </li>
                    <?php }
                    } ?>
                </ul>
            </div>
        <?php } ?>
    </section>

<?php include '../includes/admin_footer.php'; ?>
