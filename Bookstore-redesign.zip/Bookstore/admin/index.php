<?php
// ==========================================
// admin/index.php - Overview / Statistik
// ==========================================
require_once '../includes/init.php';

// Ambil 1 angka dari query COUNT()
function hitung($conn, $sql)
{
    return mysqli_fetch_assoc(mysqli_query($conn, $sql))['jumlah'];
}

$total_buku     = hitung($conn, "SELECT COUNT(*) AS jumlah FROM books");
$total_user     = hitung($conn, "SELECT COUNT(*) AS jumlah FROM users WHERE role = 'user'");
$total_kategori = hitung($conn, "SELECT COUNT(*) AS jumlah FROM categories WHERE parent_id IS NOT NULL");
$perlu_verifikasi = hitung($conn, "SELECT COUNT(*) AS jumlah FROM orders WHERE status = '" . STATUS_MENUNGGU_VERIF . "'");

// Semua buku, diurutkan dari stok paling sedikit
$stok_menipis = mysqli_query($conn, "SELECT judul, stok FROM books ORDER BY stok ASC");

$judul_halaman = 'Overview';
include '../includes/admin_header.php';
?>

    <section class="admin-section">
        <h2>Overview</h2>

        <div class="stat-cards">
            <div class="stat-card">
                <p class="stat-number"><?php echo $total_buku; ?></p>
                <p class="stat-label">Total Buku</p>
            </div>
            <div class="stat-card">
                <p class="stat-number"><?php echo $total_user; ?></p>
                <p class="stat-label">Total User</p>
            </div>
            <div class="stat-card">
                <p class="stat-number"><?php echo $total_kategori; ?></p>
                <p class="stat-label">Total Sub-Genre</p>
            </div>
            <a href="transaksi.php" class="stat-card">
                <p class="stat-number"><?php echo $perlu_verifikasi; ?></p>
                <p class="stat-label">Pembayaran Perlu Diverifikasi</p>
            </a>
        </div>

        <h3>Stok Menipis</h3>
        <div class="table-wrap"><table class="admin-table">
            <thead>
                <tr><th>Judul</th><th>Stok Tersisa</th></tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($stok_menipis)) { ?>
                    <tr>
                        <td><?php echo e($row['judul']); ?></td>
                        <td><?php echo (int)$row['stok']; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table></div>
    </section>

<?php include '../includes/admin_footer.php'; ?>
