<?php
// ==========================================
// admin/hapus_buku.php - Hapus buku (lalu balik ke dashboard)
// ==========================================
require_once '../includes/init.php';
wajib_admin();

$id = (int)($_GET['id'] ?? 0);

// Ambil nama file cover dulu, biar filenya ikut dihapus
$stmt = mysqli_prepare($conn, "SELECT cover_image FROM books WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$book = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if ($book) {
    $stmt = mysqli_prepare($conn, "DELETE FROM books WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);

    if ($book['cover_image']) {
        @unlink(__DIR__ . '/../assets/images/books/' . basename($book['cover_image']));
    }
}

header("Location: dashboard.php");
exit;
