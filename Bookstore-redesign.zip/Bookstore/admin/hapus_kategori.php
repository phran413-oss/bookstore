<?php
// ==========================================
// admin/hapus_kategori.php - Hapus kategori (lalu balik ke daftar)
// ==========================================
require_once '../includes/init.php';
wajib_admin();

$id = (int)($_GET['id'] ?? 0);

// Catatan: di database, parent_id & books.category_id pakai "ON DELETE SET NULL".
// Hapus kategori utama -> sub-genre-nya TIDAK ikut terhapus, tapi jadi kategori utama.
// Hapus sub-genre -> buku di dalamnya tetap ada, hanya kehilangan kategorinya.
$stmt = mysqli_prepare($conn, "DELETE FROM categories WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

header("Location: kategori.php");
exit;
