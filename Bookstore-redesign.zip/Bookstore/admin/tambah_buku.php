<?php
// ==========================================
// admin/tambah_buku.php - Tambah buku baru
// ==========================================
require_once '../includes/init.php';
wajib_admin();

$error = "";
$book = $_POST;   // supaya isian form tidak hilang kalau ada error
$kategori_result = mysqli_query($conn, "SELECT * FROM categories WHERE parent_id IS NOT NULL");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cover_image = "";

    // Upload cover (opsional)
    if (isset($_FILES['cover']) && $_FILES['cover']['error'] != UPLOAD_ERR_NO_FILE) {
        $cover_image = simpan_gambar($_FILES['cover'], __DIR__ . '/../assets/images/books', $error);
    }

    if (!$error) {
        $is_bestseller = isset($_POST['is_bestseller']) ? 1 : 0;
        $is_trending   = isset($_POST['is_trending']) ? 1 : 0;

        $stmt = mysqli_prepare($conn, "INSERT INTO books (judul, penulis, harga, stok, category_id, deskripsi, cover_image, is_bestseller, is_trending) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssdiissii", $_POST['judul'], $_POST['penulis'], $_POST['harga'], $_POST['stok'], $_POST['category_id'], $_POST['deskripsi'], $cover_image, $is_bestseller, $is_trending);

        if (mysqli_stmt_execute($stmt)) {
            header("Location: dashboard.php");
            exit;
        }
        $error = "Gagal menambahkan buku.";
    }
}

$judul_halaman = 'Tambah Buku';
$teks_tombol = 'Simpan Buku';
include '../includes/admin_header.php';
?>

    <section class="admin-section">
        <h2>Tambah Buku Baru</h2>
        <?php if ($error) { ?><p class="auth-error"><?php echo e($error); ?></p><?php } ?>
        <?php include '../includes/form_buku.php'; ?>
    </section>

<?php include '../includes/admin_footer.php'; ?>
