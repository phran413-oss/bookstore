<?php
// ==========================================
// admin/edit_buku.php - Edit buku
// ==========================================
require_once '../includes/init.php';
wajib_admin();

$id = (int)($_GET['id'] ?? 0);
$error = "";

$stmt = mysqli_prepare($conn, "SELECT * FROM books WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$book = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$book) {
    die("Buku tidak ditemukan. <a href='dashboard.php'>Kembali</a>");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cover_image = $book['cover_image'];   // default: pakai cover lama

    // Ada cover baru? -> simpan, lalu hapus file cover lama
    if (isset($_FILES['cover']) && $_FILES['cover']['error'] != UPLOAD_ERR_NO_FILE) {
        $cover_baru = simpan_gambar($_FILES['cover'], __DIR__ . '/../assets/images/books', $error);
        if ($cover_baru) {
            if ($book['cover_image']) {
                @unlink(__DIR__ . '/../assets/images/books/' . basename($book['cover_image']));
            }
            $cover_image = $cover_baru;
        }
    }

    if (!$error) {
        $is_bestseller = isset($_POST['is_bestseller']) ? 1 : 0;
        $is_trending   = isset($_POST['is_trending']) ? 1 : 0;

        $stmt = mysqli_prepare($conn, "UPDATE books SET judul=?, penulis=?, harga=?, stok=?, category_id=?, deskripsi=?, cover_image=?, is_bestseller=?, is_trending=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, "ssdiissiii", $_POST['judul'], $_POST['penulis'], $_POST['harga'], $_POST['stok'], $_POST['category_id'], $_POST['deskripsi'], $cover_image, $is_bestseller, $is_trending, $id);

        if (mysqli_stmt_execute($stmt)) {
            header("Location: dashboard.php");
            exit;
        }
        $error = "Gagal menyimpan perubahan.";
    }
}

$kategori_result = mysqli_query($conn, "SELECT * FROM categories WHERE parent_id IS NOT NULL");

$judul_halaman = 'Edit Buku';
$teks_tombol = 'Simpan Perubahan';
include '../includes/admin_header.php';
?>

    <section class="admin-section">
        <h2>Edit Buku: <?php echo e($book['judul']); ?></h2>
        <?php if ($error) { ?><p class="auth-error"><?php echo e($error); ?></p><?php } ?>
        <?php include '../includes/form_buku.php'; ?>
    </section>

<?php include '../includes/admin_footer.php'; ?>
