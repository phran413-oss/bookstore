<?php
// ==========================================
// admin/transaksi.php - Daftar pesanan masuk
// ==========================================
require_once '../includes/init.php';
wajib_admin();

// Yang perlu diurus admin ditaruh paling atas:
// 1) bukti pembayaran menunggu dicek, 2) sudah dibayar tapi belum selesai diproses, 3) sisanya
$result = mysqli_query($conn, "
    SELECT orders.*, users.nama AS nama_user
    FROM orders
    JOIN users ON orders.user_id = users.id
    ORDER BY
        CASE orders.status
            WHEN '" . STATUS_MENUNGGU_VERIF . "' THEN 0
            WHEN '" . STATUS_DIPROSES . "' THEN 1
            ELSE 2
        END,
        orders.created_at DESC
");

$judul_halaman = 'Transaksi';
include '../includes/admin_header.php';
?>

    <section class="admin-section">
        <h2>Transaksi</h2>
        <p class="form-hint mb-20">
            Pesanan dengan status <strong>Menunggu Verifikasi</strong> berarti user sudah upload bukti pembayaran dan perlu kamu cek.
        </p>

        <div class="table-wrap"><table class="admin-table">
            <thead>
                <tr>
                    <th>Order #</th>
                    <th>User</th>
                    <th>Total</th>
                    <th>Metode Bayar</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($result) == 0) { ?>
                    <tr><td colspan="7" class="text-center text-muted">Belum ada pesanan masuk.</td></tr>
                <?php } else {
                    while ($order = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo e(nomor_order($order['id'])); ?></td>
                        <td><?php echo e($order['nama_user']); ?></td>
                        <td><?php echo rupiah($order['total_harga']); ?></td>
                        <td><?php echo e($order['metode_pembayaran']); ?></td>
                        <td><?php echo e(tanggal($order['created_at'])); ?></td>
                        <td><?php echo badge_status($order['status']); ?></td>
                        <td><a href="transaksi_detail.php?id=<?php echo (int)$order['id']; ?>" class="btn-edit">Detail</a></td>
                    </tr>
                <?php }
                } ?>
            </tbody>
        </table></div>
    </section>

<?php include '../includes/admin_footer.php'; ?>
