<?php
// ==========================================
// admin/cetak.php - Halaman cetak (label pengiriman / struk), langsung buka dialog print
//   cetak.php?id=12&tipe=label | struk | keduanya
// ==========================================
require_once '../includes/init.php';
require_once '../includes/cetak_blok.php';
wajib_admin();

$id = (int)($_GET['id'] ?? 0);
$tipe = $_GET['tipe'] ?? 'keduanya';
if (!in_array($tipe, ['label', 'struk', 'keduanya'])) {
    $tipe = 'keduanya';
}

list($order, $items) = ambil_order($conn, $id);
if (!$order) {
    die("Pesanan tidak ditemukan.");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak <?php echo e(nomor_order($order['id'])); ?></title>
    <?php css_cetak(); ?>
    <style>
        body { margin: 0; padding: 20px; background: #fff; font-family: Arial, sans-serif; }
        .toolbar { margin-bottom: 16px; }
        .toolbar button { background: #2f80ed; color: #fff; border: none; padding: 10px 20px; border-radius: 6px; font-size: 14px; cursor: pointer; }
        .toolbar a { margin-left: 12px; font-size: 14px; }
        .cetak-grid { align-items: flex-start; }
        @page { margin: 10mm; }
        @media print {
            .toolbar { display: none !important; }
            body { padding: 0; }
            .strk-box { border: none; }
        }
    </style>
</head>
<body>
    <div class="toolbar">
        <button type="button" onclick="window.print()">🖨️ Cetak</button>
        <a href="transaksi_detail.php?id=<?php echo (int)$order['id']; ?>">&larr; Kembali ke detail pesanan</a>
    </div>

    <div class="cetak-grid">
        <?php if ($tipe == 'label' || $tipe == 'keduanya') { ?>
            <div class="cetak-item"><?php blok_label($order, $items); ?></div>
        <?php } ?>
        <?php if ($tipe == 'struk' || $tipe == 'keduanya') { ?>
            <div class="cetak-item"><?php blok_struk($order, $items); ?></div>
        <?php } ?>
    </div>

    <script>window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 300); });</script>
</body>
</html>
