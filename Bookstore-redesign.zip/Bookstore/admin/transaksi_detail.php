<?php
// ==========================================
// admin/transaksi_detail.php - Detail pesanan, cek bukti bayar, proses pesanan
// ==========================================
require_once '../includes/init.php';
require_once '../includes/cetak_blok.php';
wajib_admin();

$id = (int)($_GET['id'] ?? 0);
list($order, $items) = ambil_order($conn, $id);

if (!$order) {
    die("Pesanan tidak ditemukan. <a href='transaksi.php'>Kembali</a>");
}

// ---------- AKSI ADMIN ----------
// Tiap aksi cuma boleh dari status tertentu (kolom "dari"), hasilnya status baru ("jadi").
// Kondisi "AND status = ?" di query mencegah aksi dobel / loncat urutan.
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $aksi = $_POST['action'] ?? '';
    $alur = [
        'terima_bayar'  => ['dari' => STATUS_MENUNGGU_VERIF, 'jadi' => STATUS_DIPROSES],
        'tolak_bayar'   => ['dari' => STATUS_MENUNGGU_VERIF, 'jadi' => STATUS_DITOLAK],
        'selesaikan'    => ['dari' => STATUS_DIPROSES,       'jadi' => STATUS_SELESAI],
    ];

    if (isset($alur[$aksi])) {
        $catatan = ($aksi == 'tolak_bayar') ? trim($_POST['catatan'] ?? '') : null;

        $stmt = mysqli_prepare($conn, "UPDATE orders SET status = ?, catatan_admin = ? WHERE id = ? AND status = ?");
        mysqli_stmt_bind_param($stmt, "ssis", $alur[$aksi]['jadi'], $catatan, $id, $alur[$aksi]['dari']);
        mysqli_stmt_execute($stmt);
    }

    header("Location: transaksi_detail.php?id=" . $id);
    exit;
}

$judul_halaman = 'Pesanan ' . nomor_order($order['id']);
include '../includes/admin_header.php';
?>

    <section class="admin-section">
        <a href="transaksi.php" class="back-link print-hide">&larr; Kembali ke daftar pesanan</a>

        <div class="transaksi-detail-box col-stack">

            <div class="print-hide flex-between mb-15">
                <div>
                    <h2>Pesanan <?php echo e(nomor_order($order['id'])); ?></h2>
                    <p class="detail-order-meta">
                        Dipesan oleh <strong><?php echo e($order['nama_user']); ?></strong> (<?php echo e($order['email_user']); ?>)
                        <br>
                        <?php echo e(tanggal($order['created_at'])); ?>
                    </p>
                </div>
                <div><?php echo badge_status($order['status']); ?></div>
            </div>

            <div class="table-wrap print-hide mb-15"><table class="admin-table">
                <thead>
                    <tr><th>Buku</th><th>Jumlah</th><th>Harga</th><th>Subtotal</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item) { ?>
                        <tr>
                            <td><?php echo e($item['judul']); ?></td>
                            <td><?php echo (int)$item['jumlah']; ?></td>
                            <td><?php echo rupiah($item['harga']); ?></td>
                            <td><?php echo rupiah($item['subtotal']); ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table></div>

            <p class="print-hide detail-order-total">
                <strong>Total: <?php echo rupiah($order['total_harga']); ?></strong>
            </p>
            <p class="print-hide detail-order-method">
                Metode Pembayaran: <?php echo e($order['metode_pembayaran']); ?>
            </p>

            <!-- ===== BUKTI PEMBAYARAN ===== -->
            <div class="print-hide pay-box">
                <h3>Bukti Pembayaran</h3>
                <?php if ($order['bukti_pembayaran']) { ?>
                    <p class="form-hint">Dikirim user: <?php echo e(tanggal($order['waktu_bayar'])); ?></p>
                    <?php tampil_bukti($order['bukti_pembayaran']); ?>
                    <p class="form-hint">File PDF tersimpan di folder uploads/bukti/. Cocokkan nominal <strong><?php echo rupiah($order['total_harga']); ?></strong> dengan mutasi rekening/e-wallet kamu.</p>
                <?php } else { ?>
                    <p class="form-hint">Belum ada bukti pembayaran dari user.</p>
                <?php } ?>

                <?php if ($order['status'] == STATUS_DITOLAK && $order['catatan_admin']) { ?>
                    <p class="form-hint">Alasan penolakan: <?php echo e($order['catatan_admin']); ?></p>
                <?php } ?>

                <?php if ($order['status'] == STATUS_MENUNGGU_VERIF) { ?>
                    <div class="flex-wrap-gap">
                        <form method="POST" action="">
                            <input type="hidden" name="action" value="terima_bayar">
                            <button type="submit" class="btn-checkout">Terima Pembayaran</button>
                        </form>
                        <form method="POST" action="" class="inline-form">
                            <input type="hidden" name="action" value="tolak_bayar">
                            <input type="text" name="catatan" placeholder="Alasan (mis. nominal tidak sesuai)" required class="input-catatan">
                            <button type="submit" class="btn-delete">Tolak</button>
                        </form>
                    </div>
                <?php } ?>
            </div>

            <!-- ===== LABEL PENGIRIMAN & STRUK (berdampingan) ===== -->
            <?php css_cetak(); ?>
            <div class="cetak-grid mb-20">
                <div class="cetak-item">
                    <h3>Label Pengiriman</h3>
                    <?php blok_label($order, $items); ?>
                    <div class="cetak-aksi">
                        <a href="cetak.php?id=<?php echo (int)$order['id']; ?>&tipe=label" target="_blank" class="btn-print">Cetak Label</a>
                    </div>
                </div>
                <div class="cetak-item">
                    <h3>Struk</h3>
                    <?php blok_struk($order, $items); ?>
                    <div class="cetak-aksi">
                        <a href="cetak.php?id=<?php echo (int)$order['id']; ?>&tipe=struk" target="_blank" class="btn-print">Cetak Struk</a>
                        <a href="cetak.php?id=<?php echo (int)$order['id']; ?>&tipe=keduanya" target="_blank" class="btn-print">Cetak Keduanya</a>
                    </div>
                </div>
            </div>

            <!-- ===== TANDAI SELESAI (setelah pembayaran diterima) ===== -->
            <?php if ($order['status'] == STATUS_DIPROSES) { ?>
                <form method="POST" action="" class="print-hide text-right">
                    <input type="hidden" name="action" value="selesaikan">
                    <button type="submit" class="btn-checkout">Tandai Pesanan Selesai</button>
                </form>
            <?php } elseif ($order['status'] == STATUS_SELESAI) { ?>
                <p class="print-hide text-right text-ok">Pesanan ini sudah selesai.</p>
            <?php } ?>

        </div>
    </section>

<?php include '../includes/admin_footer.php'; ?>
