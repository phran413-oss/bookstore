<?php
// ==========================================
// admin/dashboard.php - Kelola Buku (daftar)
// ==========================================
require_once '../includes/init.php';

$result = mysqli_query($conn, "SELECT * FROM books ORDER BY id DESC");

$judul_halaman = 'Kelola Buku';
include '../includes/admin_header.php';
?>

    <section class="admin-section">
        <div class="admin-header">
            <h2>Kelola Buku</h2>
            <a href="tambah_buku.php" class="btn-add">+ Tambah Buku</a>
        </div>

        <div class="table-wrap"><table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Cover</th>
                    <th>Judul</th>
                    <th>Penulis</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($book = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo (int)$book['id']; ?></td>
                        <td>
                            <?php if ($book['cover_image']) { ?>
                                <img src="<?php echo e(cover_url($book)); ?>" alt="<?php echo e($book['judul']); ?>" class="table-cover">
                            <?php } else { ?>
                                <span class="text-muted">-</span>
                            <?php } ?>
                        </td>
                        <td><?php echo e($book['judul']); ?></td>
                        <td><?php echo e($book['penulis']); ?></td>
                        <td><?php echo rupiah($book['harga']); ?></td>
                        <td><?php echo (int)$book['stok']; ?></td>
                        <td class="admin-actions">
                            <a href="edit_buku.php?id=<?php echo (int)$book['id']; ?>" class="btn-edit">Edit</a>
                            <a href="hapus_buku.php?id=<?php echo (int)$book['id']; ?>"
                               class="btn-delete"
                               onclick="return confirm('Yakin mau hapus buku ini?');">Hapus</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table></div>
    </section>

<?php include '../includes/admin_footer.php'; ?>
