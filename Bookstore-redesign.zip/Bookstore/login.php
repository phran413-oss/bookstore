<?php
// ==========================================
// login.php - Login & Register (1 halaman, 2 tab)
// ==========================================
require_once 'includes/init.php';

$error_login = "";
$error_register = "";
$success_register = "";
$tab_aktif = 'login';

// ---------- PROSES LOGIN ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && ($_POST['action'] ?? '') == 'login') {

    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = mysqli_prepare($conn, "SELECT id, nama, password, role FROM users WHERE email = ?");
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if (!$user) {
        $error_login = "Email belum terdaftar.";
    } elseif (!password_verify($password, $user['password'])) {
        $error_login = "Password salah.";
    } else {
        // Login berhasil -> simpan data user ke session
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['nama'] = $user['nama'];
        $_SESSION['role'] = $user['role'];

        header("Location: " . ($user['role'] == 'admin' ? "admin/index.php" : "index.php"));
        exit;
    }
}

// ---------- PROSES REGISTER ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && ($_POST['action'] ?? '') == 'register') {

    $tab_aktif = 'register';
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $cek = mysqli_prepare($conn, "SELECT id FROM users WHERE email = ?");
    mysqli_stmt_bind_param($cek, "s", $email);
    mysqli_stmt_execute($cek);
    mysqli_stmt_store_result($cek);

    if (mysqli_stmt_num_rows($cek) > 0) {
        $error_register = "Email sudah terdaftar.";
    } else {
        // Password di-hash dulu, jangan pernah disimpan polos
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = mysqli_prepare($conn, "INSERT INTO users (nama, email, password) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sss", $nama, $email, $password_hash);

        if (mysqli_stmt_execute($stmt)) {
            $success_register = "Pendaftaran berhasil! Silakan login.";
            $tab_aktif = 'login';
        } else {
            $error_register = "Terjadi kesalahan, coba lagi.";
        }
    }
}

$judul_halaman = 'Login / Register';
$tampilkan_search = false;
include 'includes/header.php';
?>

    <section class="auth-section">
        <div class="auth-box">

            <div class="auth-tabs">
                <button type="button" class="tab-btn <?php echo $tab_aktif == 'login' ? 'active' : ''; ?>" onclick="showTab('login')" id="tab-login">Login</button>
                <button type="button" class="tab-btn <?php echo $tab_aktif == 'register' ? 'active' : ''; ?>" onclick="showTab('register')" id="tab-register">Register</button>
            </div>

            <!-- ===== TAB LOGIN ===== -->
            <div id="form-login" class="tab-content" style="display:<?php echo $tab_aktif == 'login' ? 'block' : 'none'; ?>;">
                <?php if ($success_register) { ?>
                    <p class="auth-success"><?php echo e($success_register); ?></p>
                <?php } ?>
                <?php if ($error_login) { ?>
                    <p class="auth-error"><?php echo e($error_login); ?></p>
                <?php } ?>

                <form method="POST" action="">
                    <input type="hidden" name="action" value="login">

                    <label>Email</label>
                    <input type="email" name="email" required>

                    <label>Password</label>
                    <input type="password" name="password" required>

                    <button type="submit">Login</button>
                </form>
            </div>

            <!-- ===== TAB REGISTER ===== -->
            <div id="form-register" class="tab-content" style="display:<?php echo $tab_aktif == 'register' ? 'block' : 'none'; ?>;">
                <?php if ($error_register) { ?>
                    <p class="auth-error"><?php echo e($error_register); ?></p>
                <?php } ?>

                <form method="POST" action="">
                    <input type="hidden" name="action" value="register">

                    <label>Nama</label>
                    <input type="text" name="nama" required>

                    <label>Email</label>
                    <input type="email" name="email" required>

                    <label>Password</label>
                    <input type="password" name="password" required minlength="6">

                    <button type="submit">Daftar</button>
                </form>
            </div>

        </div>
    </section>

    <script>
        // Pindah tab tanpa reload halaman
        function showTab(tab) {
            ['login', 'register'].forEach(function (t) {
                document.getElementById('form-' + t).style.display = (t === tab) ? 'block' : 'none';
                document.getElementById('tab-' + t).classList.toggle('active', t === tab);
            });
        }
    </script>

<?php include 'includes/footer.php'; ?>
