<?php
// ==========================================
// pembayaran.php - Instruksi bayar + upload bukti pembayaran
// ==========================================
require_once 'includes/init.php';
require_once 'includes/payment_methods.php';
wajib_login();

$user_id = $_SESSION['user_id'];
$order_id = (int)($_GET['order_id'] ?? 0);

list($order, $items) = ambil_order($conn, $order_id, $user_id);
if (!$order) {
    die("Pesanan tidak ditemukan. <a href='riwayat_pesanan.php'>Kembali</a>");
}

// Halaman ini cuma untuk pesanan yang masih di tahap pembayaran.
// Kalau sudah dibayar/diproses/dibatalkan -> lihat di halaman struk.
$tahap_bayar = [STATUS_MENUNGGU_BAYAR, STATUS_DITOLAK, STATUS_MENUNGGU_VERIF];
if (!in_array($order['status'], $tahap_bayar)) {
    header("Location: invoice.php?order_id=" . $order_id);
    exit;
}

$error = "";
$sukses = "";
$bisa_upload = in_array($order['status'], [STATUS_MENUNGGU_BAYAR, STATUS_DITOLAK]);
$aksi = $_POST['action'] ?? '';

// ---------- UPLOAD BUKTI PEMBAYARAN ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $aksi == 'upload_bukti' && $bisa_upload) {

    if (!isset($_FILES['bukti']) || $_FILES['bukti']['error'] == UPLOAD_ERR_NO_FILE) {
        $error = "Pilih file bukti pembayaran dulu.";
    } else {
        $nama_file = simpan_bukti_pdf($_FILES['bukti'], __DIR__ . '/uploads/bukti', $order_id, $error);

        if ($nama_file) {
            $status_baru = STATUS_MENUNGGU_VERIF;
            $stmt = mysqli_prepare($conn, "
                UPDATE orders
                SET bukti_pembayaran = ?, waktu_bayar = NOW(), catatan_admin = NULL, status = ?
                WHERE id = ? AND user_id = ?
            ");
            mysqli_stmt_bind_param($stmt, "ssii", $nama_file, $status_baru, $order_id, $user_id);
            mysqli_stmt_execute($stmt);

            hapus_file_bukti($order['bukti_pembayaran']);   // bukti lama (kalau upload ulang) dibuang

            header("Location: pembayaran.php?order_id=" . $order_id . "&uploaded=1");
            exit;
        }
    }
}

// ---------- BATALKAN PESANAN (selama belum bayar) ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $aksi == 'batal' && $bisa_upload) {
    mysqli_begin_transaction($conn);
    $status_batal = STATUS_DIBATALKAN;
    $stmt = mysqli_prepare($conn, "UPDATE orders SET status = ? WHERE id = ? AND user_id = ? AND status IN (?, ?)");
    $s1 = STATUS_MENUNGGU_BAYAR;
    $s2 = STATUS_DITOLAK;
    mysqli_stmt_bind_param($stmt, "siiss", $status_batal, $order_id, $user_id, $s1, $s2);
    mysqli_stmt_execute($stmt);
    if (mysqli_stmt_affected_rows($stmt) > 0) {
        kembalikan_stok($conn, $order_id);   // stok buku dikembalikan
    }
    mysqli_commit($conn);

    header("Location: riwayat_pesanan.php");
    exit;
}

if (isset($_GET['uploaded'])) {
    $sukses = "Bukti pembayaran berhasil dikirim. Admin akan memeriksanya sebentar lagi.";
}

// Data tujuan bayar sesuai metode yang dipilih saat checkout
$metode = $METODE_PEMBAYARAN[$order['metode_pembayaran']] ?? null;

$judul_halaman = 'Pembayaran';
$tampilkan_search = false;
include 'includes/header.php';
?>

    <section class="checkout-section">
        <?php $langkah_aktif = 3; include 'includes/steps.php'; ?>
        <h2>Pembayaran Pesanan <?php echo e(nomor_order($order['id'])); ?></h2>

        <?php if ($error) { ?><p class="auth-error"><?php echo e($error); ?></p><?php } ?>
        <?php if ($sukses) { ?><p class="auth-success"><?php echo e($sukses); ?></p><?php } ?>

        <?php if ($order['status'] == STATUS_DITOLAK) { ?>
            <p class="auth-error">
                Bukti pembayaran ditolak admin<?php echo $order['catatan_admin'] ? ': ' . e($order['catatan_admin']) : '.'; ?>
                Silakan upload ulang bukti yang benar.
            </p>
        <?php } ?>

        <div class="checkout-layout">

            <!-- ===== KIRI: Ringkasan + status ===== -->
            <div class="checkout-summary">
                <h3>Ringkasan Pesanan</h3>
                <?php foreach ($items as $item) { ?>
                    <div class="checkout-item-row">
                        <span><?php echo e($item['judul']); ?> x<?php echo (int)$item['jumlah']; ?></span>
                        <span><?php echo rupiah($item['subtotal']); ?></span>
                    </div>
                <?php } ?>
                <div class="checkout-item-row checkout-total-row">
                    <strong>Total Bayar</strong>
                    <strong><?php echo rupiah($order['total_harga']); ?></strong>
                </div>
                <p class="form-hint">Status: <?php echo badge_status($order['status']); ?></p>
            </div>

            <!-- ===== KANAN: Cara bayar + upload ===== -->
            <div class="checkout-payment">

                <?php if ($bisa_upload) { ?>
                    <h3>1. Lakukan Pembayaran</h3>
                    <div class="pay-box">
                        <p>Metode: <strong><?php echo e($metode['label'] ?? $order['metode_pembayaran']); ?></strong></p>

                        <?php if ($metode && $metode['tipe'] == 'qris') { ?>
                            <?php if (is_file(__DIR__ . '/assets/images/qris.png')) { ?>
                                <img src="assets/images/qris.png" alt="QRIS Bookstore" class="pay-qris">
                            <?php } else { ?>
                                <p class="form-hint">Scan QRIS toko. (Admin: taruh gambar QRIS di <code>assets/images/qris.png</code>)</p>
                            <?php } ?>
                        <?php } elseif ($metode) { ?>
                            <p><?php echo $metode['tipe'] == 'bank' ? 'No. Rekening' : 'No. ' . e($metode['label']); ?>:
                                <strong class="pay-nomor"><?php echo e($metode['tujuan']); ?></strong></p>
                            <p>Atas nama: <strong><?php echo e($metode['atas_nama']); ?></strong></p>
                        <?php } ?>

                        <p>Nominal transfer: <strong><?php echo rupiah($order['total_harga']); ?></strong></p>
                    </div>

                    <h3>2. Upload Bukti Pembayaran</h3>
                    <form method="POST" action="" enctype="multipart/form-data" id="form-bukti">
                        <input type="hidden" name="action" value="upload_bukti">
                        <input type="file" name="bukti" id="input-bukti" accept="image/jpeg,image/png,image/webp" required>
                        <p class="form-hint">Screenshot / foto bukti transfer (JPG, PNG, atau WEBP). Ukuran file bebas, otomatis dikompres dan diubah jadi PDF.</p>
                        <button type="submit" class="btn-checkout">Kirim Bukti Pembayaran</button>
                    </form>

                    <form method="POST" action="" onsubmit="return confirm('Batalkan pesanan ini?');" class="form-batal">
                        <input type="hidden" name="action" value="batal">
                        <button type="submit" class="btn-delete">Batalkan Pesanan</button>
                    </form>

                <?php } else { ?>
                    <h3>Bukti Pembayaran Terkirim</h3>
                    <p class="form-hint">Dikirim: <?php echo e(tanggal($order['waktu_bayar'])); ?>. Admin sedang memeriksa pembayaranmu.
                        Struk resmi akan muncul di halaman Pesanan Saya setelah pembayaran diterima.</p>
                    <?php if ($order['bukti_pembayaran']) { ?>
                        <?php tampil_bukti($order['bukti_pembayaran'], 360); ?>
                    <?php } ?>
                <?php } ?>

            </div>
        </div>

        <p class="mt-20"><a href="riwayat_pesanan.php" class="back-link">&larr; Pesanan Saya</a></p>
    </section>

    <script>
    // Kompres gambar bukti jadi JPEG di browser sebelum dikirim (jadi server tidak wajib punya ekstensi GD).
    (function () {
        var form = document.getElementById('form-bukti');
        var input = document.getElementById('input-bukti');
        if (!form || !input) return;
        var sudah = false;

        form.addEventListener('submit', function (ev) {
            var f = input.files && input.files[0];
            if (sudah || !f || f.type === 'image/jpeg' && f.size < 300 * 1024) return;   // JPEG kecil: kirim apa adanya
            ev.preventDefault();

            var kirim = function () { sudah = true; form.submit(); };
            var url = URL.createObjectURL(f);
            var img = new Image();
            img.onload = function () {
                try {
                    var skala = Math.min(1, 1300 / Math.max(img.naturalWidth, img.naturalHeight));
                    var c = document.createElement('canvas');
                    c.width = Math.max(1, Math.round(img.naturalWidth * skala));
                    c.height = Math.max(1, Math.round(img.naturalHeight * skala));
                    var ctx = c.getContext('2d');
                    ctx.fillStyle = '#fff';
                    ctx.fillRect(0, 0, c.width, c.height);   // PNG transparan -> latar putih
                    ctx.drawImage(img, 0, 0, c.width, c.height);
                    c.toBlob(function (blob) {
                        URL.revokeObjectURL(url);
                        if (blob) {
                            try {
                                var dt = new DataTransfer();
                                dt.items.add(new File([blob], 'bukti.jpg', { type: 'image/jpeg' }));
                                input.files = dt.files;
                            } catch (e) {}
                        }
                        kirim();
                    }, 'image/jpeg', 0.7);
                } catch (e) { kirim(); }
            };
            img.onerror = function () { URL.revokeObjectURL(url); kirim(); };
            img.src = url;
        });
    })();
    </script>

<?php include 'includes/footer.php'; ?>
