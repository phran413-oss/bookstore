<?php
// ==========================================
// wishlist.php - Halaman Wishlist (wajib login)
// ==========================================
require_once 'includes/init.php';
wajib_login();

// JOIN wishlist + books: wishlist cuma nyimpen user_id & book_id, detail bukunya ada di books
$stmt = mysqli_prepare($conn, "
    SELECT books.*
    FROM wishlist
    JOIN books ON wishlist.book_id = books.id
    WHERE wishlist.user_id = ?
");
mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$judul_halaman = 'Wishlist';
include 'includes/header.php';
?>

    <section class="book-section">
        <h2>Wishlist</h2>
        <div class="book-wrapper">
            <div class="book-list book-grid">
                <?php if (mysqli_num_rows($result) == 0) { ?>
                    <p class="shelf-empty">Belum ada buku di wishlist kamu. Simpan buku yang menarik dari halaman detailnya.</p>
                <?php } else {
                    while ($book = mysqli_fetch_assoc($result)) {
                        include 'includes/book_card.php';
                    }
                } ?>
            </div>
        </div>
    </section>

<?php include 'includes/footer.php'; ?>
