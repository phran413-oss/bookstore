<?php
// ==========================================
// book_detail.php - Detail Buku
// ==========================================
require_once 'includes/init.php';

$id = (int)($_GET['id'] ?? 0);

// LEFT JOIN: buku tanpa kategori tetap bisa dibuka
$stmt = mysqli_prepare($conn, "
    SELECT books.*, categories.nama_kategori AS genre
    FROM books
    LEFT JOIN categories ON books.category_id = categories.id
    WHERE books.id = ?
");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$book = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$book) {
    http_response_code(404);
    die("Buku tidak ditemukan. <a href='index.php'>Kembali ke Home</a>");
}

$pesan_wishlist = "";
$pesan_cart = "";
$aksi = $_POST['action'] ?? '';

// ---------- TOMBOL WISHLIST & KERANJANG (wajib login) ----------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && in_array($aksi, ['toggle_wishlist', 'add_to_cart'])) {
    wajib_login();
    $user_id = $_SESSION['user_id'];

    if ($aksi == 'toggle_wishlist') {
        $cek = mysqli_prepare($conn, "SELECT id FROM wishlist WHERE user_id = ? AND book_id = ?");
        mysqli_stmt_bind_param($cek, "ii", $user_id, $id);
        mysqli_stmt_execute($cek);
        mysqli_stmt_store_result($cek);

        if (mysqli_stmt_num_rows($cek) > 0) {
            $q = mysqli_prepare($conn, "DELETE FROM wishlist WHERE user_id = ? AND book_id = ?");
            $pesan_wishlist = "Dihapus dari wishlist.";
        } else {
            $q = mysqli_prepare($conn, "INSERT INTO wishlist (user_id, book_id) VALUES (?, ?)");
            $pesan_wishlist = "Ditambahkan ke wishlist!";
        }
        mysqli_stmt_bind_param($q, "ii", $user_id, $id);
        mysqli_stmt_execute($q);
    }

    if ($aksi == 'add_to_cart') {
        // Kalau buku sudah ada di cart, jumlahnya +1 (bukan bikin baris baru)
        $cek = mysqli_prepare($conn, "SELECT id FROM cart WHERE user_id = ? AND book_id = ?");
        mysqli_stmt_bind_param($cek, "ii", $user_id, $id);
        mysqli_stmt_execute($cek);
        $row_cart = mysqli_fetch_assoc(mysqli_stmt_get_result($cek));

        if ($row_cart) {
            $q = mysqli_prepare($conn, "UPDATE cart SET jumlah = jumlah + 1 WHERE id = ?");
            mysqli_stmt_bind_param($q, "i", $row_cart['id']);
        } else {
            $q = mysqli_prepare($conn, "INSERT INTO cart (user_id, book_id, jumlah) VALUES (?, ?, 1)");
            mysqli_stmt_bind_param($q, "ii", $user_id, $id);
        }
        mysqli_stmt_execute($q);
        $pesan_cart = "Ditambahkan ke keranjang!";
    }
}

// Status wishlist SEKARANG (buat nentuin teks tombol)
$is_wishlisted = false;
if (isset($_SESSION['user_id'])) {
    $cek2 = mysqli_prepare($conn, "SELECT id FROM wishlist WHERE user_id = ? AND book_id = ?");
    mysqli_stmt_bind_param($cek2, "ii", $_SESSION['user_id'], $id);
    mysqli_stmt_execute($cek2);
    mysqli_stmt_store_result($cek2);
    $is_wishlisted = mysqli_stmt_num_rows($cek2) > 0;
}

$judul_halaman = $book['judul'];
$tampilkan_search = false;
include 'includes/header.php';
?>

    <section class="detail-section">
        <a href="javascript:history.back()" class="back-link">&larr; Kembali</a>

        <div class="detail-box">
            <div class="detail-left">
                <img src="<?php echo e(cover_url($book, 250, 350)); ?>" alt="<?php echo e($book['judul']); ?>">
            </div>

            <div class="detail-right">
                <h1><?php echo e($book['judul']); ?></h1>
                <p class="detail-penulis">oleh <?php echo e($book['penulis']); ?></p>
                <?php if ($book['genre']) { ?>
                    <span class="detail-genre"><?php echo e($book['genre']); ?></span>
                <?php } ?>
                <p class="detail-price"><?php echo rupiah($book['harga']); ?></p>
                <p class="detail-deskripsi">
                    <?php echo $book['deskripsi'] ? nl2br(e($book['deskripsi'])) : '(Belum ada deskripsi untuk buku ini)'; ?>
                </p>

                <?php if ($pesan_wishlist) { ?>
                    <p class="auth-success"><?php echo e($pesan_wishlist); ?></p>
                <?php } ?>
                <?php if ($pesan_cart) { ?>
                    <p class="auth-success"><?php echo e($pesan_cart); ?></p>
                <?php } ?>

                <div class="detail-actions">
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="toggle_wishlist">
                        <button type="submit" class="btn-wishlist">
                            <?php echo $is_wishlisted ? 'Di Wishlist &middot; klik untuk hapus' : 'Tambah ke Wishlist'; ?>
                        </button>
                    </form>
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="add_to_cart">
                        <button type="submit" class="btn-cart">Tambah ke Keranjang</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Komentar: baru tampilan, belum nyambung ke database -->
        <div class="comment-section">
            <h3>Komentar</h3>
            <form class="comment-form">
                <textarea placeholder="Tulis komentar kamu di sini..." rows="3"></textarea>
                <button type="button">Kirim Komentar</button>
            </form>
            <div class="comment-list">
                <p class="comment-empty">Belum ada komentar untuk buku ini.</p>
            </div>
        </div>
    </section>

<?php include 'includes/footer.php'; ?>
