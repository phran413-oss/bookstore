<?php
// ==========================================
// logout.php - Keluar/logout
// ==========================================
session_start();
session_destroy();   // hapus semua data session (user_id, nama, role)

header("Location: index.php");
exit;
