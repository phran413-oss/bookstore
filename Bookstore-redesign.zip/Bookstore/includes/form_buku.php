<?php
// ==========================================
// includes/form_buku.php - Form buku (dipakai tambah_buku.php & edit_buku.php)
// Butuh: $book (array data buku; kosong kalau tambah), $kategori_result, $teks_tombol
// ==========================================
?>
<form method="POST" action="" enctype="multipart/form-data" class="admin-form">
    <label>Judul</label>
    <input type="text" name="judul" value="<?php echo e($book['judul'] ?? ''); ?>" required>

    <label>Penulis</label>
    <input type="text" name="penulis" value="<?php echo e($book['penulis'] ?? ''); ?>" required>

    <label>Harga (Rp)</label>
    <input type="number" name="harga" min="0" value="<?php echo e($book['harga'] ?? ''); ?>" required>

    <label>Stok</label>
    <input type="number" name="stok" min="0" value="<?php echo e($book['stok'] ?? ''); ?>" required>

    <label>Kategori</label>
    <select name="category_id" required>
        <option value="">-- Pilih Kategori --</option>
        <?php while ($kat = mysqli_fetch_assoc($kategori_result)) { ?>
            <option value="<?php echo (int)$kat['id']; ?>" <?php echo (($book['category_id'] ?? '') == $kat['id']) ? 'selected' : ''; ?>>
                <?php echo e($kat['nama_kategori']); ?>
            </option>
        <?php } ?>
    </select>

    <label>Deskripsi</label>
    <textarea name="deskripsi" rows="4"><?php echo e($book['deskripsi'] ?? ''); ?></textarea>

    <?php if (!empty($book['cover_image'])) { ?>
        <label>Cover Saat Ini</label>
        <img src="<?php echo e(cover_url($book)); ?>" alt="Cover saat ini" class="current-cover">
        <label>Ganti Cover (kosongkan kalau tidak ingin ganti)</label>
    <?php } else { ?>
        <label>Cover Buku</label>
    <?php } ?>
    <input type="file" name="cover" accept="image/jpeg,image/png,image/webp">

    <p class="form-hint">"What's new" ditentukan otomatis dari tanggal buku ditambahkan (7 hari terakhir).</p>
    <label class="checkbox-label">
        <input type="checkbox" name="is_bestseller" <?php echo !empty($book['is_bestseller']) ? 'checked' : ''; ?>> Tampilkan di "Best seller"
    </label>
    <label class="checkbox-label">
        <input type="checkbox" name="is_trending" <?php echo !empty($book['is_trending']) ? 'checked' : ''; ?>> Tampilkan di "Trending now"
    </label>

    <button type="submit"><?php echo e($teks_tombol); ?></button>
</form>
