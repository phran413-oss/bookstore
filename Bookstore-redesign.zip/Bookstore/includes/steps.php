<?php
// ==========================================
// includes/steps.php - Indikator langkah belanja (Keranjang > Checkout > Bayar > Selesai)
// Sebelum include, set $langkah_aktif = 1..4
// ==========================================
$langkah_aktif = $langkah_aktif ?? 1;
$daftar_langkah = ['Keranjang', 'Checkout', 'Pembayaran', 'Struk'];
?>
<ol class="steps" aria-label="Langkah belanja">
    <?php foreach ($daftar_langkah as $i => $nama) {
        $no = $i + 1;
        $kelas = $no < $langkah_aktif ? 'done' : ($no == $langkah_aktif ? 'active' : '');
    ?>
        <li class="<?php echo $kelas; ?>">
            <span class="step-no"><?php echo $no < $langkah_aktif ? ikon('check', 14) : $no; ?></span>
            <span class="step-label"><?php echo e($nama); ?></span>
        </li>
    <?php } ?>
</ol>
