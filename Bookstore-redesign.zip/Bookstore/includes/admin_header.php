<?php
// ==========================================
// includes/admin_header.php - Bagian atas halaman admin (head + sidebar)
// Sebelum include, set:  $judul_halaman = "..."
// Penutupnya ada di admin_footer.php
// ==========================================
require_once __DIR__ . '/icons.php';
wajib_admin();
$judul_halaman = isset($judul_halaman) ? $judul_halaman . ' - Admin Bookstore' : 'Admin Bookstore';

// Menu admin: file => [label, ikon]. File lain (edit, tambah, detail) ikut menyorot menu induknya.
$menu_admin = [
    'index.php'     => ['Overview',  'chart'],
    'dashboard.php' => ['Kelola Buku', 'book'],
    'transaksi.php' => ['Transaksi', 'receipt'],
    'kategori.php'  => ['Kategori',  'layers'],
];
$induk_menu = [
    'tambah_buku.php'      => 'dashboard.php',
    'edit_buku.php'        => 'dashboard.php',
    'transaksi_detail.php' => 'transaksi.php',
    'edit_kategori.php'    => 'kategori.php',
];
$file_aktif = basename($_SERVER['SCRIPT_NAME']);
$file_aktif = $induk_menu[$file_aktif] ?? $file_aktif;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($judul_halaman); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin-body">

    <div class="admin-shell">
        <aside class="admin-sidebar">
            <a href="index.php" class="logo">
                <span class="logo-mark"><?php echo ikon('book', 18); ?></span>
                <span>Bookstore <small>Admin</small></span>
            </a>

            <nav class="admin-nav">
                <?php foreach ($menu_admin as $file => $m) { ?>
                    <a href="<?php echo $file; ?>" class="<?php echo $file_aktif == $file ? 'active' : ''; ?>">
                        <?php echo ikon($m[1], 18); ?><span><?php echo e($m[0]); ?></span>
                    </a>
                <?php } ?>
            </nav>

            <div class="admin-sidebar-foot">
                <a href="../index.php" target="_blank"><?php echo ikon('external', 16); ?><span>Lihat toko</span></a>
                <div class="admin-me">
                    <span class="avatar"><?php echo e(strtoupper(mb_substr($_SESSION['nama'], 0, 1))); ?></span>
                    <span class="admin-me-name"><?php echo e($_SESSION['nama']); ?></span>
                </div>
                <a href="../logout.php" class="admin-logout"><?php echo ikon('logout', 16); ?><span>Logout</span></a>
            </div>
        </aside>

        <main class="admin-main">
