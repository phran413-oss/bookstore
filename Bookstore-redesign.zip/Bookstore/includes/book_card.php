<?php
// ==========================================
// includes/book_card.php - Kartu 1 buku (dipakai di Home, Genre, Search, Wishlist)
// Butuh variabel $book (1 baris dari tabel books)
// ==========================================
?>
<a href="book_detail.php?id=<?php echo (int)$book['id']; ?>" class="book-card">
    <div class="book-cover">
        <img src="<?php echo e(cover_url($book)); ?>" alt="<?php echo e($book['judul']); ?>" loading="lazy">
        <?php if (!empty($book['is_bestseller'])) { ?><span class="book-tag">Best seller</span><?php } ?>
    </div>
    <p class="book-title"><?php echo e($book['judul']); ?></p>
    <?php if (!empty($book['penulis'])) { ?><p class="book-author"><?php echo e($book['penulis']); ?></p><?php } ?>
    <p class="book-price"><?php echo rupiah($book['harga']); ?></p>
</a>
