<?php
// ==========================================
// includes/header.php - Bagian atas halaman user (head + navbar)
// Sebelum include, halaman bisa set:  $judul_halaman = "..." ; $tampilkan_search = false;
// ==========================================
require_once __DIR__ . '/icons.php';

$judul_halaman = isset($judul_halaman) ? $judul_halaman . ' - Bookstore' : 'Bookstore';
$tampilkan_search = $tampilkan_search ?? true;

// Menu yang sedang aktif (buat highlight di navbar)
$file_aktif = basename($_SERVER['SCRIPT_NAME']);
$menu_aktif = [
    'index.php'          => 'home',
    'books.php'          => 'books',
    'books_list.php'     => 'books',
    'wishlist.php'       => 'wishlist',
    'riwayat_pesanan.php'=> 'pesanan',
    'invoice.php'        => 'pesanan',
    'pembayaran.php'     => 'pesanan',
][$file_aktif] ?? '';

// Jumlah item di keranjang (buat badge di ikon cart)
$jumlah_cart = 0;
if (isset($_SESSION['user_id'])) {
    $q_cart = mysqli_prepare($conn, "SELECT COALESCE(SUM(jumlah), 0) FROM cart WHERE user_id = ?");
    mysqli_stmt_bind_param($q_cart, "i", $_SESSION['user_id']);
    mysqli_stmt_execute($q_cart);
    mysqli_stmt_bind_result($q_cart, $jumlah_cart);
    mysqli_stmt_fetch($q_cart);
    mysqli_stmt_close($q_cart);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($judul_halaman); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE; ?>assets/css/style.css">
</head>
<body>

    <header class="navbar">
        <div class="navbar-inner">
            <a href="index.php" class="logo">
                <span class="logo-mark"><?php echo ikon('book', 18); ?></span>
                <span>Bookstore</span>
            </a>

            <button type="button" class="nav-toggle" id="nav-toggle" aria-label="Buka menu" aria-expanded="false" aria-controls="nav-panel">
                <?php echo ikon('menu', 22); ?>
            </button>

            <div class="nav-panel" id="nav-panel">
                <nav class="nav-links">
                    <a href="index.php" class="<?php echo $menu_aktif == 'home' ? 'active' : ''; ?>">Home</a>
                    <a href="books.php" class="<?php echo $menu_aktif == 'books' ? 'active' : ''; ?>">Books</a>
                    <a href="wishlist.php" class="<?php echo $menu_aktif == 'wishlist' ? 'active' : ''; ?>">Wishlist</a>
                    <a href="riwayat_pesanan.php" class="<?php echo $menu_aktif == 'pesanan' ? 'active' : ''; ?>">Pesanan Saya</a>
                    <a href="#">Forum</a>
                </nav>

                <?php if ($tampilkan_search) { ?>
                    <form method="GET" action="search.php" class="search-box" role="search">
                        <?php echo ikon('search', 18); ?>
                        <input type="text" name="q" placeholder="Cari judul atau penulis..." value="<?php echo e($keyword ?? ''); ?>" aria-label="Cari buku">
                    </form>
                <?php } ?>
            </div>

            <div class="nav-icons">
                <a href="cart.php" class="icon-btn" aria-label="Keranjang" title="Keranjang">
                    <?php echo ikon('cart', 21); ?>
                    <?php if ($jumlah_cart > 0) { ?><span class="cart-count"><?php echo (int)$jumlah_cart; ?></span><?php } ?>
                </a>
                <?php if (isset($_SESSION['user_id'])) { ?>
                    <span class="user-info" title="<?php echo e($_SESSION['nama']); ?>">
                        <span class="avatar"><?php echo e(strtoupper(mb_substr($_SESSION['nama'], 0, 1))); ?></span>
                        <span class="user-name"><?php echo e($_SESSION['nama']); ?></span>
                    </span>
                    <a href="logout.php" class="logout-link">Logout</a>
                <?php } else { ?>
                    <a href="login.php" class="btn-login">Masuk</a>
                <?php } ?>
            </div>
        </div>
    </header>

    <main class="page">
