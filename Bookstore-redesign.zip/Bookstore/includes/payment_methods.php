<?php
// ==========================================
// includes/payment_methods.php - Daftar metode pembayaran + tujuan bayarnya
// ==========================================
// GANTI nomor rekening / nomor e-wallet di bawah dengan punya toko kamu.
// (Angka di sini cuma contoh/placeholder.)
//
// Key array (misal 'GoPay') = nilai yang disimpan di kolom orders.metode_pembayaran
//   tipe      : qris | ewallet | bank  (dipakai buat nentuin teks petunjuk)
//   tujuan    : nomor rekening / nomor e-wallet
//   atas_nama : nama pemilik rekening / akun

$METODE_PEMBAYARAN = [
    'QRIS' => [
        'label'     => 'QRIS',
        'tipe'      => 'qris',
        'tujuan'    => '',
        'atas_nama' => 'Bookstore',
        // Taruh gambar QRIS toko kamu di assets/images/qris.png, nanti otomatis tampil
    ],
    'GoPay' => [
        'label'     => 'GoPay',
        'tipe'      => 'ewallet',
        'tujuan'    => '0812-3456-7890',
        'atas_nama' => 'Bookstore',
    ],
    'DANA' => [
        'label'     => 'DANA',
        'tipe'      => 'ewallet',
        'tujuan'    => '0812-3456-7890',
        'atas_nama' => 'Bookstore',
    ],
    'OVO' => [
        'label'     => 'OVO',
        'tipe'      => 'ewallet',
        'tujuan'    => '0812-3456-7890',
        'atas_nama' => 'Bookstore',
    ],
    'Transfer BNI' => [
        'label'     => 'Transfer Bank BNI',
        'tipe'      => 'bank',
        'tujuan'    => '0123456789',
        'atas_nama' => 'Bookstore',
    ],
    'Transfer BCA' => [
        'label'     => 'Transfer Bank BCA',
        'tipe'      => 'bank',
        'tujuan'    => '9876543210',
        'atas_nama' => 'Bookstore',
    ],
];
