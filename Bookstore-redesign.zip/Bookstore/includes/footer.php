<?php
// ==========================================
// includes/footer.php - Bagian bawah halaman user (footer + penutup HTML)
// ==========================================
?>
    </main>

    <footer class="site-footer">
        <div class="footer-content">
            <div class="footer-about">
                <p class="footer-title"><span class="logo-mark"><?php echo ikon('book', 16); ?></span> Bookstore</p>
                <p class="footer-desc">Pusat buku lengkap dan terpercaya, siap menemani perjalanan dan ilmu pengetahuan baru.</p>
                <div class="footer-socials">
                    <a href="#" title="Facebook"><img src="assets/icons/FC.png" alt="Facebook"></a>
                    <a href="#" title="Instagram"><img src="assets/icons/IG.png" alt="Instagram"></a>
                    <a href="#" title="Twitter"><img src="assets/icons/TW.png" alt="Twitter"></a>
                    <a href="#" title="Youtube"><img src="assets/icons/YT.png" alt="Youtube"></a>
                </div>
            </div>

            <div class="footer-col">
                <p class="footer-heading">Jelajahi</p>
                <a href="index.php">Home</a>
                <a href="books.php">Books</a>
                <a href="wishlist.php">Wishlist</a>
                <a href="riwayat_pesanan.php">Pesanan Saya</a>
            </div>

            <div class="footer-contact">
                <p class="footer-heading">Hubungi Kami</p>
                <p>Jl. Pelajar Indonesia No. 45, Kebayoran Baru, Jakarta Selatan, 12190</p>
                <p>WhatsApp / HP: +62 812-3456-7890</p>
                <p>Email: support@bookstore-example.com / halo@bookstore.id</p>
                <p>Jam Operasional: Senin - Sabtu, 08.00 - 20.00 WIB</p>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="footer-links">
                <a href="privacy-policy.php">Privacy Policy</a>
                <a href="terms-of-service.php">Terms of Service</a>
                <a href="cookie-preferences.php">Cookie Preferences</a>
            </div>
            <p class="footer-copyright">&copy; <?php echo date('Y'); ?> Bookstore. All Rights Reserved.</p>
        </div>
    </footer>

    <script>
        // Tombol menu di tampilan HP
        (function () {
            var tombol = document.getElementById('nav-toggle');
            var panel = document.getElementById('nav-panel');
            if (!tombol || !panel) return;
            tombol.addEventListener('click', function () {
                var buka = panel.classList.toggle('open');
                tombol.setAttribute('aria-expanded', buka ? 'true' : 'false');
            });
        })();
    </script>

</body>
</html>
<?php mysqli_close($conn); ?>
