<?php
// ==========================================
// includes/init.php - Dipanggil PALING ATAS di setiap halaman
// Isinya: session, koneksi database, dan fungsi-fungsi bantu
// ==========================================

session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helpers.php';
