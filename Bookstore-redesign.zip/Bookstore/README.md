# Bookstore (PHP + MySQL)

Toko buku sederhana: user (katalog, wishlist, keranjang, checkout, bayar + upload bukti) dan admin (kelola buku/kategori, verifikasi pembayaran).

## Cara jalanin (XAMPP)
1. Taruh folder ini di `htdocs/Bookstore`.
2. phpMyAdmin → buat database `bookstore` → Import `database/bookstore.sql`.
   (Kalau database lama sudah ada: jalankan `database/migrasi_pembayaran.sql` saja.)
3. Buka `http://localhost/Bookstore/`.
4. Akun contoh: `admin@bookstore.com` / `admin123` (admin), `budi@mail.com` / `user123` (user).
5. **Ganti nomor rekening / e-wallet** di `includes/payment_methods.php`. Gambar QRIS toko → `assets/images/qris.png`.

## Alur pesanan
`Menunggu Pembayaran` → user upload bukti → `Menunggu Verifikasi` → admin cek:
- **Terima** → `Diproses` (user dapat struk "LUNAS") → admin **Tandai Selesai** → `Selesai`
- **Tolak** (+ alasan) → `Pembayaran Ditolak` → user upload ulang

User bisa membatalkan selama belum bayar (stok dikembalikan).

## Struktur
```
index.php, books.php, ...   halaman user (logika di atas file, tampilan di bawah)
admin/                      halaman admin
includes/
  init.php                  session + koneksi + helper (di-require paling atas tiap halaman)
  config.php                setting database
  helpers.php               e(), rupiah(), status, upload gambar, query bersama
  payment_methods.php       daftar metode & tujuan bayar
  header.php / footer.php   layout user
  admin_header.php / admin_footer.php   layout admin
  book_card.php, form_buku.php          potongan tampilan yang dipakai ulang
database/                   bookstore.sql (install baru), migrasi_pembayaran.sql (DB lama)
uploads/bukti/              bukti pembayaran user (otomatis jadi PDF terkompresi: bukti_000010_xxxx.pdf)
assets/                     css, icons, images/books
```

## Kompres bukti pembayaran (butuh ekstensi GD)
Bukti yang diupload dikompres jadi PDF memakai ekstensi PHP **GD**. Kalau muncul error `imagecreatefromstring`, aktifkan dulu:
1. XAMPP Control Panel → Apache → **Config** → `PHP (php.ini)`.
2. Cari baris `;extension=gd`, hapus titik koma di depannya jadi `extension=gd`.
3. Simpan, lalu **Stop → Start** Apache.
Tanpa GD, upload JPG tetap jalan tapi tidak dikompres, dan PNG/WEBP ditolak dengan pesan jelas.
