<?php
// ==========================================
// search.php - Hasil pencarian buku
// ==========================================
require_once 'includes/init.php';

$keyword = trim($_GET['q'] ?? '');
$result = null;

if ($keyword !== '') {
    // LIKE + % = cari yang "mengandung" keyword (misal "sapi" nemuin "Sapiens")
    $stmt = mysqli_prepare($conn, "SELECT * FROM books WHERE judul LIKE ? OR penulis LIKE ?");
    $like = "%" . $keyword . "%";
    mysqli_stmt_bind_param($stmt, "ss", $like, $like);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
}

$judul_halaman = 'Hasil Pencarian';
include 'includes/header.php';
?>

    <section class="book-section">
        <h2>
            <?php echo $keyword !== '' ? 'Hasil pencarian untuk "' . e($keyword) . '"' : 'Cari buku'; ?>
        </h2>

        <div class="book-wrapper">
            <div class="book-list book-grid">
                <?php if ($keyword === '') { ?>
                    <p class="shelf-empty">Ketik judul buku atau nama penulis di kotak pencarian di atas.</p>
                <?php } elseif (mysqli_num_rows($result) == 0) { ?>
                    <p class="shelf-empty">Tidak ada buku yang cocok dengan "<?php echo e($keyword); ?>".</p>
                <?php } else {
                    while ($book = mysqli_fetch_assoc($result)) {
                        include 'includes/book_card.php';
                    }
                } ?>
            </div>
        </div>
    </section>

<?php include 'includes/footer.php'; ?>
