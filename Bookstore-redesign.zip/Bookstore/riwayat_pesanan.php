<?php
// ==========================================
// riwayat_pesanan.php - Riwayat Pesanan User
// ==========================================
require_once 'includes/init.php';
wajib_login();

$stmt = mysqli_prepare($conn, "SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$judul_halaman = 'Pesanan Saya';
include 'includes/header.php';
?>

    <section class="admin-section">
        <h2>Pesanan Saya</h2>

        <?php if (mysqli_num_rows($result) == 0) { ?>
            <div class="empty-state"><?php echo ikon('receipt', 40); ?><strong>Belum ada pesanan</strong><p>Kamu belum pernah checkout. Yuk mulai belanja!</p><a href="books.php" class="btn-checkout">Jelajahi buku</a></div>
        <?php } else { ?>
            <div class="table-wrap"><table class="admin-table">
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Tanggal</th>
                        <th>Total</th>
                        <th>Metode Bayar</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($order = mysqli_fetch_assoc($result)) { ?>
                        <tr>
                            <td><?php echo e(nomor_order($order['id'])); ?></td>
                            <td><?php echo e(tanggal($order['created_at'])); ?></td>
                            <td><?php echo rupiah($order['total_harga']); ?></td>
                            <td><?php echo e($order['metode_pembayaran']); ?></td>
                            <td><?php echo badge_status($order['status']); ?></td>
                            <td>
                                <?php if (in_array($order['status'], [STATUS_MENUNGGU_BAYAR, STATUS_DITOLAK])) { ?>
                                    <a href="pembayaran.php?order_id=<?php echo (int)$order['id']; ?>" class="btn-edit">Bayar</a>
                                <?php } else { ?>
                                    <a href="invoice.php?order_id=<?php echo (int)$order['id']; ?>" class="btn-edit">Lihat Struk</a>
                                <?php } ?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table></div>
        <?php } ?>
    </section>

<?php include 'includes/footer.php'; ?>
